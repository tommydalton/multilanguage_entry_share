<?php
	header("Content-Type: text/html; charset=utf-8");
	$root = realpath($_SERVER["DOCUMENT_ROOT"]);

	if (!$_POST) exit;

  // require '$root/libs/share/j-folder/php/validation.php';
	// require '$root/libs/share/j-folder/php/csrf.php';

	require dirname(__FILE__)."/validation.php";
	require dirname(__FILE__)."/csrf.php";

/************************************************/
/* Your data */
/************************************************/
/* Your email goes here */
$your_email = "share@hola401k.com";

/* Your name or your company name goes here */
$your_name = "HOLA401k Principal";

/* Message subject */
$your_subject = "Principal® | Biblioteca compartida HOLA401k";

/************************************************/
/* Settings */
/************************************************/
	/* Select validation for fields */
	/* If you want to validate field - true, if you don't - false */
	$validate_name 		 = true;
	$validate_email		 = true;
	$validate_sname 		 = true;
	$validate_semail		 = true;
	$validate_comments	 = true;

	/* Select the action */
	/* If you want to do the action - true, if you don't - false */
	$send_letter = true;

/************************************************/
/* Variables */
/************************************************/
	/* Error variables */
	$error_text		= array();
	$error_message	= '';

	/* Info variables */
	//$sipadress = '67.210.97.18';
	//$sdate = date("d.m.Y");
	//$stime = date("H:i:s");

	/* POST data */
	$sname		= (isset($_POST["sname"]))			        ? strip_tags(trim($_POST["sname"]))								 : false;
	$semail		= (isset($_POST["semail"]))		        	? strip_tags(trim($_POST["semail"]))							 : false;
	$name		  = (isset($_POST["name"]))			          ? strip_tags(trim($_POST["name"]))								 : false;
	$email		= (isset($_POST["email"]))			        ? strip_tags(trim($_POST["email"]))							 	 : false;
	//$comments	= (isset($_POST["message"]))		        ? strip_tags(trim($_POST["message"]))						  : false;
	$comments	= (isset($_POST["message"]))		        ? $_POST["message"]		                             : false;
	$libname	= (isset($_POST["libname"]))		        ? $_POST["libname"]		                             : false;
	$token 		= (isset($_POST["token_comment"]))	    ? strip_tags(trim($_POST["token_comment"]))				 : false;
	$notify		= (isset($_POST["notify"]))			        ? strip_tags(trim($_POST["notify"])) 							 : "dont notify me";


	$sname		= htmlspecialchars($sname, ENT_QUOTES, 'UTF-8');
	$semail		= htmlspecialchars($semail, ENT_QUOTES, 'UTF-8');
	$name		  = htmlspecialchars($name, ENT_QUOTES, 'UTF-8');
	$email		= htmlspecialchars($email, ENT_QUOTES, 'UTF-8');
	//no action to preserve HTML markup
	//$libname	= htmlspecialchars($libname, ENT_QUOTES, 'UTF-8');
  //$comments	= htmlspecialchars($comments, ENT_QUOTES, 'UTF-8');
	//$comments	= htmlentities($comments, ENT_HTML5, 'UTF-8');
	//$comments	= htmlspecialchars($comments, ENT_HTML5, 'UTF-8');
	$token		= htmlspecialchars($token, ENT_QUOTES, 'UTF-8');
	$notify		= htmlspecialchars($notify, ENT_QUOTES, 'UTF-8');

  $libname	= substr($libname, 0, 80);
	$sname 		= substr($sname, 0, 80);
	$semail		= substr($semail, 0, 80);
	$name 		= substr($name, 0, 80);
	$email		= substr($email, 0, 80);
	$comments	= substr($comments, 0, 6000);
	$notify		= substr($notify, 0, 20);

/************************************************/
/* CSRF protection */
/************************************************/
	$new_token = new CSRF('comment');
	if (!$new_token->check_token($token)) {
		echo '<div class="error-message unit"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Símbolo incorrecto. Por favor, vuelva a cargar esta página web</div>';
		exit;
	}

/************************************************/
/* Validation */
/************************************************/
  /* SName */
	if ($validate_sname){
		$result = validateSName($sname, 1);
		if ($result !== "valid") {
			$error_text[] = $result;
		}
	}

	/* SEmail */
	if ($validate_semail){
		$result = validateSEmail($semail);
		if ($result !== "valid") {
			$error_text[] = $result;
		}
	}

	/* Name */
	if ($validate_name){
		$result = validateName($name, 1);
		if ($result !== "valid") {
			$error_text[] = $result;
		}
	}

	/* Email */
	if ($validate_email){
		$result = validateEmail($email);
		if ($result !== "valid") {
			$error_text[] = $result;
		}
	}

	/* Comments */
	if ($validate_comments){
		$result = validateComments($comments, 20);
		if ($result !== "valid") {
			$error_text[] = $result;
		}
	}

	/* If validation error occurs */
	if ($error_text) {
		foreach ($error_text as $val) {
			$error_message .= '<li>' . $val . '</li>';
		}
		echo '<div class="error-message unit"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Los siguientes errores ocurrieron:<ul>' . $error_message . '</ul></div>';
		exit;
	}

/************************************************/
/* Sending email */
/************************************************/
	if ($send_letter) {

		/* Send email using sendmail function */
		/* If you want to use sendmail - true, if you don't - false */
		/* If you will use sendmail function - do not forget to set '$smtp' variable to 'false' */
		$sendmail = false;
		if ($sendmail) {
			// require '$root/libs/share/j-folder/php/phpmailer/PHPMailerAutoload.php';
			// require '$root/libs/share/j-folder/php/message.php';
			require dirname(__FILE__)."/phpmailer/PHPMailerAutoload.php";
			require dirname(__FILE__)."/message.php";
			$mail = new PHPMailer;
			$mail->isSendmail();
			// set word wrap to 50 characters
			$mail->WordWrap = 50;
			// set email format to HTML
			$mail->IsHTML(true);
			$mail->From = $email;
			$mail->CharSet = "UTF-8";
			$mail->FromName = "HOLA401k Principal";
			$mail->Encoding = "base64";
			$mail->ContentType = "text/html";
			$mail->addAddress($your_email, $your_name);
			$mail->Subject = $your_subject;
			$mail->Body = $letter;
			$mail->AltBody = "Utilizar un cliente de correo electrónico compatible con HTML";
		}

		/* Send email using smtp function */
		/* If you want to use smtp - true, if you don't - false */
		/* If you will use smtp function - do not forget to set '$sendmail' variable to 'false' */
		$sipadress = '67.210.97.18';
		$sdate = date("d.m.Y");
		$stime = date("H:i:s");
		$today = getdate();
		$wd = $today['weekday'];
		$d = $today['mday'];
    $m = $today['month'];
    $y = $today['year'];
		$smtp = true;
		if ($smtp) {
			// require '$root/libs/share/j-folder/php/phpmailer/PHPMailerAutoload.php';
			// require '$root/libs/share/j-folder/php/message.php';
			require dirname(__FILE__)."/phpmailer/PHPMailerAutoload.php";
			require dirname(__FILE__)."/message.php";
			$mail = new PHPMailer;
			$mail->isSMTP();											// Set mailer to use SMTP
			//$mail->Host = "67.210.97.18";		// Specify main and backup server
			//$mail->Host = "localhost";		// Specify main and backup server
			//$mail->Host = "mail.hola401k.com";		// Specify main and backup server
			//$mail->Host = "server.risdistributiontande.com";		// Specify main and backup server
			$mail->Host = "hola401k.com";		// Specify main and backup server
			$mail->SMTPAuth = true;										// Enable SMTP authentication
			$mail->Username = "share@hola401k.com";  // SMTP username
			$mail->Password = "@hola401k"; // SMTP password WORKS HOLA401k
			$mail->SMTPSecure = "ssl";		 // Enable encryption WORKS HOLA401k
			$mail->Port = 465;						 // SMTP Port WORKS HOLA401k
			// $mail->SMTPSecure = "tls";									// Enable encryption, 'ssl' also accepted
			// $mail->Port = 465;											// SMTP Port number e.g. smtp.gmail.com uses port 465
			$mail->From = $email;
			// set word wrap to 50 characters
			$mail->WordWrap = 50;
			// set email format to HTML
			$mail->IsHTML(true);
			$mail->CharSet = "UTF-8";
			$mail->FromName = "Principal Financial Group | HOLA401k";
			$mail->Encoding = "base64";
			$mail->Timeout = 200;
			$mail->SMTPDebug = 0;
			$mail->ContentType = "text/html";
			$mail->AddBCC($your_email, $your_name);
			$mail->Subject = $your_subject;
			$mail->Body = $letter;
			$mail->AltBody = "Utilizar un cliente de correo electrónico compatible con HTML";
		}

		/* Multiple email recepients */
		/* If you want to add multiple email recepients - true, if you don't - false */
		/* Enter email and name of the recipients */
		$recipients = true;
		if ($recipients) {

			$mail->AddAddress($email, $name);
			$mail->AddBCC($semail, $sname);

			// $recipients = array("share@hola401k.com" => "@hola401k",
			// 					// "tdalton@rootleveldesign.com" => "Tommy Design",
			// 					"rootleveldesign@gmail.com" => "Tommy GMail"
			// 					);
			// foreach ($recipients as $email => $name) {
			// 	$mail->AddBCC($email, $name);
			// }
			// foreach ($recipients as $semail => $sname) {
			// 	$mail->AddBCC($semail, $sname);
			// }
		}

		/* if error occurs while email sending */
		if(!$mail->send()) {
			echo '<div class="error-message unit"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Error de correo: ' . $mail->ErrorInfo . '</div>';
			exit;
		}
	}

/************************************************/
/* Success message */
/************************************************/
	echo '<div class="success-message unit"><i class="fa fa-check"></i> Sus selecciones de video fueron compartidas con '.$sname.'.</div>';
?>
