<?php

/******************************************************/
/* Validation methods */
/******************************************************/
	/* Name */
	function validateName($name, $min_length) {
		$error_text = "Introduzca su nombre";
		$len = mb_strlen($name, 'UTF-8');
		return ($len < $min_length) ? $error_text : "valid";
	}

	/* Email */
	function validateEmail($email){
		$error_text = "Formato de correo electrónico incorrecto para el remitente";
		$email_template = "/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/";
		return (preg_match($email_template, $email) !== 1) ? $error_text : "valid";
	}

	/* SName */
	function validateSName($sname, $min_length) {
		$error_text = "Ingrese el nombre del destinatario";
		$slen = mb_strlen($sname, 'UTF-8');
		return ($slen < $min_length) ? $error_text : "valid";
	}

	/* SEmail */
	function validateSEmail($semail){
		$error_text = "Formato de correo electrónico incorrecto para el destinatario";
		$semail_template = "/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/";
		return (preg_match($semail_template, $semail) !== 1) ? $error_text : "valid";
	}

	/* Message */
	function validateComments($message, $min_length) {
		$error_text = "No ha seleccionado ningún video de biblioteca para compartir. Cierre este formulario y seleccione al menos una presentación de vídeo.";
		$len = mb_strlen($message, 'UTF-8');
		return ($len < $min_length) ? $error_text : "valid";
	}
?>
