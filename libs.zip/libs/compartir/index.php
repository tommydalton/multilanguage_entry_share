<?php
  $root = realpath($_SERVER["DOCUMENT_ROOT"]);
	require "$root/libs/compartir/j-folder/php/csrf.php";
	$new_token = new CSRF('comment');
?>

<!DOCTYPE html>
<html lang="en">
<head>

	<!--Global Meta Compatibility Included-->
	<title>Compartir Formulario estático | Hispanic Online Learning Access</title>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta http-equiv="Location" content="https://www.hola401k.com/libs/compartir/">
  <meta name="description" content="SMTP PHP Contact Form">
  <meta name="author" content="Principal Financial Group">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">

	<!-- Stylesheets -->
	<!-- <link rel="stylesheet" href="https://www.hola401k.com/libs/compartir/j-folder/css/demo.css"> -->
	<!-- <link rel="stylesheet" href="https://www.hola401k.com/libs/compartir/j-folder/css/font-awesome.min.css"> -->
	<!-- <link rel="stylesheet" href="https://www.hola401k.com/libs/compartir/j-folder/css/j-forms.css"> -->

	<!-- Scripts -->
	<script src="https://www.hola401k.com/libs/compartir/j-folder/js/jquery.1.11.1.min.js"></script>
  <script src="https://www.hola401k.com/libs/compartir/j-folder/js/jquery.easing.1.3.js"></script>
	<script src="https://www.hola401k.com/libs/compartir/j-folder/js/jquery.validate.min.js"></script>
	<script src="https://www.hola401k.com/libs/compartir/j-folder/js/jquery.form.min.js"></script>
	<script src="https://www.hola401k.com/libs/compartir/j-folder/js/j-forms.js"></script>

	<!--[if lt IE 10]>
			<script src="j-folder/js/jquery.placeholder.min.js"></script>
		<![endif]-->

  <!-- Font Icons Package -->
  <link rel="stylesheet" href="//www.hola401k.com/font/font-awesome-4.7.0/css/font-awesome.css">

	<!-- Type Kit -->
	<script type="text/javascript" src="//use.typekit.net/reh7kad.js"></script>
	<script type="text/javascript">try{Typekit.load();}catch(e){}</script>

	<!-- Page Specific Scripts -->
	<!-- Forms Stylesheet -->
	<link href="//www.hola401k.com/css/project_forms/milestones-entry-form.css" rel="stylesheet" type="text/css">
	<link href="//www.hola401k.com/css/project_forms/template_styles_submit.css" rel="stylesheet" type="text/css">

	<!-- <script type="text/javascript" src="//www.hola401k.com/jquery/jquery-1.10.2.min.js"></script> -->
	<!-- <script type="text/javascript" src="https://www.hola401k.com/libs/compartir/js/jquery-1.3.1.min.js"></script> -->
	<!-- <script type="text/javascript" src="http://code.jquery.com/jquery-1.6.4.min.js"></script> -->

	<!-- jQuery Theme Roller CSS-->
	<link href="//www.hola401k.com/jquery/jquery-ui-1.11.4.custom/jquery-ui.css" rel="stylesheet" type="text/css">

	<!-- NO LONGER USING STYLES PER MEMBER GROUP. ===== PFG BRANDING 2017 ==========-->
	<!-- <link rel="stylesheet" href="https://www.hola401k.com/css/style_pfg2017.css"> -->

	    <!-- CSS Browser Selector -->
	    <!-- <script language="javascript" type="text/javascript" src="https://www.hola401k.com/js/css_browser_selector.js"></script> -->

	    <!--Scrolling Marquee Menu Text -->
	    <!-- <link rel="stylesheet" type="text/css" href="https://www.hola401k.com/css/prefixfreeScrollingMarqueeMenuText.css"> -->
	    <!-- <script type="text/javascript" src="https://www.hola401k.com/js/prefixfreeScrollingMarqueeMenuText.js"></script> -->

	    <!--Typekit-->
	    <!-- <script src="https://use.typekit.net/ssz5ktk.js"></script> -->
	    <!-- <script>try{Typekit.load({ async: true });}catch(e){}</script> -->

	    <!--Shadowbox-->
	    <!-- <link rel="stylesheet" type="text/css" href="https://www.hola401k.com/shadowbox/shadowbox.css"> -->
	    <!-- <script type="text/javascript" src="https://www.hola401k.com/shadowbox/shadowbox.js"></script> -->

	    <!-- <script type="text/javascript">
	    Shadowbox.init();
	    </script> -->

	<!-- Include Google Analytics-->
	<!--See Add-Ons - Modules Low Variables-->

	<!-- Global Low Variable Calls - Early Parsed (Stage 5) to call standard (Stage 9) Low Variables-->
	<!--===Disable Edit Profile By Group ID in Low Variables===-->

	<!--===Disable Banner By Group ID in Low Variables===-->

	<!--===Disable Banner By Member ID in Low Variables===-->

	<!--===Disable Banner By Group ID in Low Variables===-->

	<!-- Second Low Variable Calls - Early Parsed (Stage 5) to call standard (Stage 9) Low Variables-->
	<!-- Member Page Views Module - Tracking Tags -->

  <!-- Page Styles -->
	<style>
  @media only screen and (max-width: 4000px) and (min-width: 960px) {
  	#comments {
  		width: 930px !important;
  	}
  	#milestones .comment-form {
  		width: 930px !important;
  	}
  }
  @media only screen and (max-width: 959px) and (min-width: 768px) {
  	#comments {
  		width: 748px !important;
  	}
  	#milestones .comment-form {
  		width: 748px !important;
  	}
  }
  @media only screen and (max-width: 767px) and (min-width: 480px) {
  	#comments {
  		width: 420px !important;
  	}
  	#milestones .comment-form {
  		width: 420px !important;
  	}
  }
  @media only screen and (max-width: 479px) {
  	#comments {
  		width: 300px !important;
  	}
  	#milestones .comment-form {
  		width: 300px !important;
  	}
  }
  @media only screen and (min-width: 480px) and (max-width: 767px) {
  	.portfolio_1_4 ul li, .portfolio_1_3 ul li, .portfolio_1_2 ul li {
  		margin: 0 0 60px 0;
  		width: 420px;
  		height: 435px;
  		height: auto;
  	}
  }
  @media only screen and (min-width: 768px) and (max-width: 959px) {
  	.portfolio_1_4 ul li, .portfolio_1_3 ul li, .portfolio_1_2 ul li {
  		/*margin: 0 20px 20px 0;*/
  		width: 172px;
  		height: 220px;
  	}
  }
  @media only screen and (min-width: 960px) and (max-width: 4000px) {
  	.portfolio_1_4 ul li, .portfolio_1_3 ul li, .portfolio_1_2 ul li {
  		margin: 0 20px 20px 0;
  		width: 220px;
  		height: 280px;
  	}
  }
  .portfolio_1_4 ul li .title a {
  	font-family: "proxima-nova", sans-serif;
  	font-weight: 400;
  	font-size: 14px;
  	line-height: 15px;
  	padding: 10px 0 10px 0;
  }
  .portfolio_1_4 ul li .titlesub {
  	font-family: "proxima-nova", sans-serif;
  	font-weight: 400;
  	font-size: 11px;
  	position: relative;
  	top: -2px;
  	margin-bottom: 0px;
  }

  /*Form Specific Header Styles ==================================================*/
  #navbar_footer .navbar-text {
  	padding: 0px 0px 0px;
  	margin-left: 25px;
  	display: block;
  	width: 100%;
  	font-size: 12px;
  	/* line-height: 15px; */
  	line-height: 1.54;
  	-webkit-text-size-adjust: 100%;
  	letter-spacing: 0.1em;
  	font-weight: 300;
  	text-transform: none;
  	font-family: "proxima-nova-alt";
  	color: rgb(140, 137, 137);
  }
  input#prePop {
  	margin-bottom: 12px;
  }
  label {
  	line-height: 11px;
  	text-transform: none;
  	color: rgb(140, 137, 137);
  	font-weight: 200;
  	text-transform: none;
  	font-family: "proxima-nova-alt";
  }
  hr {
  	border: 0;
  	border-bottom: solid 1px rgba(212, 212, 255, 0.3);
  	margin: 0.5em 0;
  }
  textarea, textarea:focus, textarea:active, textarea:required {
  	padding-top: 12px;
  	padding-bottom: 12px;
  }
  p {
  	margin: 0 0 1em 0;
  }
  #milestones .field input, #milestones .field textarea, #milestones .field select {
  	color: #fff;
  	border: solid 1px rgba(41, 44, 44, 0.4);
  	color: #2e2e2e;
  	border: solid 1px #ddd;
  	background: #fefefe;
  }
  input#iSend, div#iReset {
  	color: #fff;
  	border: solid 1px rgba(41, 44, 44, 0.4);
  	color: #2e2e2e;
  	border: solid 1px #ddd;
  	background: #ddd;
  	letter-spacing: 0.1em;
  	font-weight: 400;
  	text-transform: none;
  	font-family: "proxima-nova-alt";
  	-webkit-transition: ease-out .8s;
  	-moz-transition: ease-out .8s;
  	-o-transition: ease-out .8s;
  	transition: ease-out .8s;
  	-webkit-touch-callout: none;
  	-webkit-user-select: none;
  	-khtml-user-select: none;
  	-moz-user-select: none;
  	-ms-user-select: none;
  	user-select: none;
  	text-decoration: none;
  }
  input#iSend:hover {
  	color: #00BFD5;
  	border: solid 1px rgba(41, 44, 44, 0.4);
  	background: #000;
  	letter-spacing: 0.1em;
  	font-weight: 400;
  	text-transform: none;
  	font-family: "proxima-nova-alt";
  	-webkit-transition: ease-out .2s;
  	-moz-transition: ease-out .2s;
  	-o-transition: ease-out .2s;
  	transition: ease-out .2s;
  	cursor: pointer;
  }
  div#iReset {
  	color: #000;
  	border: solid 1px rgba(255, 255, 255, 1);
  	background: rgba(255, 255, 255, 1);
  	letter-spacing: 0.1em;
  	font-weight: 400;
  	text-transform: none;
  	font-family: "proxima-nova-alt";
  	padding: 12px 20px 10px 20px;
  	width: 100%;
  	/*float: left;*/
  	font-size: 12px;
  	line-height: 12px;
  	opacity: 0.7;
  	text-align: center;
  }
  div#response, .error-view {
    color: #F2AF32;
  	/*border: solid 1px rgba(41, 44, 44, 0.4);*/
  	/*background-color: #333333;*/
  	letter-spacing: 0.1em;
  	font-weight: 400;
  	text-transform: none;
  	font-family: "proxima-nova-alt";
  	/*padding: 12px 20px 10px 20px;*/
  	width: 100%;
  	/*float: left;*/
  	font-size: 12px;
  	line-height: 12px;
  	opacity: 0.7;
  	text-align: center;
  }
  .j-forms .error-view .icon-left, .j-forms .error-view .icon-right, .j-forms span.error-view{
  	display: block;
  	width: 100%;
  	color: #F2AF32;
    background: #333;
  	font-weight: 400;
  	text-transform: none;
  	font-family: "proxima-nova-alt";
  	padding: 12px 20px 10px 20px;
  	width: 100%;
  	/*height: 16px;*/
  	font-size: 11px!important;
  	line-height: 14px!important;
  	opacity: 1;
  	text-align: center;
  	padding-left: 56px;
  }
  div#iReset i.fa {
  	font-size: 14px;
  	line-height: 12px;
  	text-align: center;
  	/*float: left;*/
  	/*text-align: left;*/
  }
  div#iReset:hover {
  	color: #00BFD5;
  	border: solid 1px rgba(41, 44, 44, 0.4);
  	background: #000;
  	letter-spacing: 0.1em;
  	font-weight: 400;
  	text-transform: none;
  	font-family: "proxima-nova-alt";
  	padding: 12px 20px 10px 20px;
  	width: 100%;
  	float: left;
  	font-size: 12px;
  	opacity: 1;
  	-webkit-transition: ease-out .2s;
  	-moz-transition: ease-out .2s;
  	-o-transition: ease-out .2s;
  	transition: ease-out .2s;
  	cursor: pointer;
  }
  #milestones div.form-title {
  	display: block;
  	width: 100%;
  	float: left;
  }
  #close_button {
  	float: right;
  	opacity: 0.7;
  	-webkit-transition: ease-out .5s;
  	-moz-transition: ease-out .5s;
  	-o-transition: ease-out .5s;
  	transition: ease-out .5s;
  }
  #close_button i.fa {
  	float: right;
  	font-size: 180%!important;
  	position: relative: top: -10px;
  }
  #close_button:hover {
  	opacity: 1;
  }
  #milestones .comment-form {
  	padding: 20px;
  	padding-top: 14px;
  }
  #comments.idle {
  	opacity: 1;
  	-webkit-transition: ease-out .2s;
  	-moz-transition: ease-out .2s;
  	-o-transition: ease-out .2s;
  	transition: ease-out .2s;
  	-ms-transform: scale(1, 1);
  	/* IE 9 */
  	-webkit-transform: scale(1, 1);
  	/* Safari */
  	transform: scale(1, 1);
  }
  #comments.closing {
  	opacity: 0.98;
  	-webkit-transition: ease-out .5s;
  	-moz-transition: ease-out .5s;
  	-o-transition: ease-out .5s;
  	transition: ease-out .5s;
  	-ms-transform: scale(0.99, 0.99);
  	/* IE 9 */
  	-webkit-transform: scale(0.99, 0.99);
  	/* Safari */
  	transform: scale(0.99, 0.99);
  }
  #sharedDisplay .sharedDisplay_title {
  	color: #FFFFFF;
  	background: transparent;
  	display: inline-block;
  	font-size: 15px;
  	line-height: 15px;
  	text-align: left;
  	position: relative;
  	top: 0;
  	left: 0;
  	font-family: "proxima-nova", sans-serif;
  	font-style: normal;
  	font-weight: 300;
  	margin-left: 0px;
  	display: inline-block;
  	padding: 6px 0px 2px 0px;
  	width: 100%;
  	/*height: 40px;*/
  }
  #sharedDisplay .sharedDisplay_subtitle {
  	color: #CBEAF1;
  	background: transparent;
  	display: inline-block;
  	font-size: 12px!important;
  	line-height: 12px!important;
  	text-align: left;
  	position: relative;
  	top: 0;
  	left: 0;
  	font-family: "proxima-nova", sans-serif;
  	font-style: normal;
  	font-weight: 300;
  	margin-left: 0px;
  	display: inline-block;
  	padding: 0px 0px 6px 0px;
  	width: 100%;
  	/*height: 40px;*/
  }

  div#response.init{
    /*border: solid 1px rgba(255, 255, 255, 1);*/
    /*background: rgba(255, 255, 255, 0.4);*/
    color: #00C4D9;
    background: #333333;
    letter-spacing: 0.1em;
    font-weight: 400;
    text-transform: none;
    font-family: "proxima-nova-alt";
    /*padding: 12px 20px 10px 20px;*/
    width: 100%;
    /* float: left; */
    font-size: 12px;
    line-height: 12px;
    opacity: 0;
    text-align: left;
    -webkit-transition: ease-out .5s;
    -moz-transition: ease-out .5s;
    -o-transition: ease-out .5s;
    transition: ease-out .5s;
  }
  div#response.message{
    /*border: solid 1px rgba(255, 255, 255, 1);*/
    /*background: rgba(255, 255, 255, 0.4);*/
    color: #00C4D9;
    /*background: #333333;*/
    letter-spacing: 0.1em;
    font-weight: 400;
    text-transform: none;
    font-family: "proxima-nova-alt";
    /*padding: 12px 20px 10px 20px;*/
    width: 100%;
    /* float: left; */
    font-size: 12px;
    line-height: 12px;
    opacity: 1;
    text-align: left;
    -webkit-transition: ease-out .5s;
    -moz-transition: ease-out .5s;
    -o-transition: ease-out .5s;
    transition: ease-out .5s;
  }
  div#response .error-message.unit{
    color: #00C4D9;
    background: #333333;
    letter-spacing: 0.1em;
    font-weight: 300;
    text-transform: none;
    font-family: "proxima-nova-alt";
    padding: 12px 12px 12px 12px;
    width: 100%;
    /* float: left; */
    font-size: 12px;
    line-height: 12px;
    opacity: 1;
    text-align: left;
    border: 2px solid #00C4D9;
    border-radius: 6px;
  }
  div#response.message:has(> div.success-message){
    background: #ffffff;
  }
  div#response.message:has(> div.error-message){
    background: #333333;
  }
  div#response .success-message.unit{
    color: #78C761;
    color: #005595;
    background: #ffffff;
    background: rgba(255, 255, 255, 0.9);
    letter-spacing: 0.1em;
    font-weight: 300;
    text-transform: none;
    font-family: "proxima-nova-alt";
    padding: 20px 12px 20px 12px;
    width: 100%;
    /* float: left; */
    font-size: 12px;
    line-height: 12px;
    opacity: 1;
    text-align: center;
    border: 2px solid #005595;
    border-radius: 6px;
  }
  div#response .error-message.unit .fa{
    letter-spacing: 0.1em;
    font-weight: 300;
    text-transform: none;
    display: inline-block;
        font: normal normal normal 14px/1 FontAwesome;
        font-size: inherit;
        text-rendering: auto;
        -webkit-font-smoothing: antialiased;
    float: left;
    font-size: 16px;
    line-height: 12px;
    opacity: 1;
    text-align: left;
    padding-right: 7px;
  }
  div#response .success-message.unit .fa{
    color: #78C761;
   letter-spacing: 0.1em;
   font-weight: 300;
   text-transform: none;
   display: inline-block;
       font: normal normal normal 14px/1 FontAwesome;
       font-size: inherit;
       text-rendering: auto;
       -webkit-font-smoothing: antialiased;
   /*float: left;*/
   font-size: 16px;
   line-height: 12px;
   opacity: 1;
   /*text-align: left;*/
   padding-right: 7px;
 }
  div#response .error-message.unit ul {
    color: #00C4D9;
    letter-spacing: 0.1em;
    font-weight: 300;
    text-transform: none;
    font-family: "proxima-nova-alt";
    padding: 0px 20px 0px 20px;
    width: 100%;
    /* float: left; */
    font-size: 12px;
    line-height: 12px;
    opacity: 1;
    text-align: left;
  }
  div#response .error-message.unit ul li {
    color: #FFEABF;
    letter-spacing: 0.1em;
    font-weight: 300;
    text-transform: none;
    font-family: "proxima-nova-alt";
    padding: 12px 20px 0px 0px;
    width: 100%;
    /* float: left; */
    font-size: 12px;
    line-height: 12px;
    opacity: 1;
    text-align: left;
  }
</style>

	<!--===EE===-->

	<style type="text/css">
	  #DOMLoadCurtain {position: absolute; height: 100%; width: 100%; top:0; left: 0; background: #fff; opacity:0.99; z-index:999999998;}
	  #DOMLoadAnimation {display: block; width:200px; position: relative; top:40%; margin:0 auto; opacity:0.60; z-index:999999999;}
	  @-webkit-keyframes uil-ring-anim {
	   0% {
	     -webkit-transform: rotate(0deg);
	     transform: rotate(0deg);
	   }
	   100% {
	     -webkit-transform: rotate(360deg);
	     transform: rotate(360deg);
	   }
	 }
	 @-moz-keyframes uil-ring-anim {
	   0% {
	     -webkit-transform: rotate(0deg);
	     transform: rotate(0deg);
	   }
	   100% {
	     -webkit-transform: rotate(360deg);
	     transform: rotate(360deg);
	   }
	 }
	 @-webkit-keyframes uil-ring-anim {
	   0% {
	     -webkit-transform: rotate(0deg);
	     transform: rotate(0deg);
	   }
	   100% {
	     -webkit-transform: rotate(360deg);
	     transform: rotate(360deg);
	   }
	 }
	 @-o-keyframes uil-ring-anim {
	   0% {
	     -webkit-transform: rotate(0deg);
	     transform: rotate(0deg);
	   }
	   100% {
	     -webkit-transform: rotate(360deg);
	     transform: rotate(360deg);
	   }
	 }
	 @keyframes uil-ring-anim {
	   0% {
	     -webkit-transform: rotate(0deg);
	     transform: rotate(0deg);
	   }
	   100% {
	     -webkit-transform: rotate(360deg);
	     transform: rotate(360deg);
	   }
	 }
	 .uil-ring-css {
	   background: none;
	   position: relative;
	   width: 200px;
	   height: 200px;
	 }
	 .uil-ring-css > div {
	   position: absolute;
	   display: block;
	   width: 160px;
	   height: 160px;
	   top: 20px;
	   left: 20px;
	   border-radius: 80px;
	   box-shadow: 0 3px 0 0 #009BCC;
	   -webkit-transform-origin: 80px 81.5px;
	   transform-origin: 80px 81.5px;
	   -webkit-animation: uil-ring-anim 3s linear infinite;
	   animation: uil-ring-anim 3s linear infinite;
	 }
	</style>
	<!--[if gte IE 9]>
	  <style type="text/css">
	    .gradient {
	       filter: none;
	    }
	  </style>
	<![endif]-->

</head>
<body>

	<div class="clear padding20"></div>

					<!-- START FORM WRAPPER and FORM -->
					 <div id="comments" style="margin-top:4%" class="idle">
						<section id="milestones">
							<div class="comment-form" id="container">
								<!-- form-title //////////////////////////////// -->
								<div class="form-title" style="font-size:140%">Compartir contenido de la biblioteca<i class="fa fa-share"></i><span id="close_button" onclick="parent.Shadowbox.close()"><i class="fa fa-window-close" aria-hidden="true"></i></span></div>
	                <div id="main">

	                  <!-- BEGIN FORM =================================================================================
	                  ============================================================================================ -->
	                  <form action="j-folder/php/action.php" method="post" class="j-forms" id="j-forms" novalidate>
                    <div id="formActive">
											<!-- start token -->
											<div class="token">
												<?php echo $new_token->get_token();?>
											</div>
                      <div class="field-header"><i class="fa fa-share-square" aria-hidden="true"></i> Enviar enlaces a:</div>
	                    <!-- field-header ////////////////////////////////-->
	                    <div class="field"><div class="unit">
	                      <input id="name" name="name" placeholder="Nombre del destinatario" type="text" required="" value="">
												<span class="entypo-user icon"></span>
												<span class="slick-tip left">Ingrese el nombre del destinatario.</span>
	                    </div></div>
	                    <!-- field-header ////////////////////////////////-->
	                    <div class="field"><div class="unit">
	                      <input id="email" name="email" placeholder="Correo electrónico del destinatario" required="" type="text"  value="">
												<span class="entypo-mail icon"></span>
												<span class="slick-tip left">Introduzca la dirección de correo electrónico del destinatario.</span>
	                    </div></div>
                      <div class="field-header"><i class="fa fa-share-alt-square" aria-hidden="true"></i> Información de los remitentes:</div>
	                    <!-- field-header ////////////////////////////////-->
	                    <div class="field"><div class="unit">
	                      <input id="sname" name="sname" placeholder="Tu nombre" type="text" required="" value="">
												<span class="entypo-user icon"></span>
												<span class="slick-tip left">Introduzca su nombre.</span>
	                    </div></div>
	                    <!-- field-header ////////////////////////////////-->
	                    <div class="field"><div class="unit">
	                      <input id="semail" name="semail" placeholder="Tu correo electrónico" required="" type="text"  value="">
												<span class="entypo-mail icon"></span>
												<span class="slick-tip left">Ingrese su dirección de correo electrónico.</span>
	                    </div></div>
                      <!-- field-header ////////////////////////////////-->
                      <!-- <div class="field"><div class="unit">
                        <p class="text">
                          <textarea spellcheck="false" id="message" name="message" rows="40" style="display:none;"></textarea>
                        </p><span class="entypo-user icon"></span> <span class="slick-tip left">Shared Video Links</span>
                      </div></div> -->
                      <div class="field-header"><i class="fa fa-check-square" aria-hidden="true"></i> Vídeos Seleccionados:</div>
                      <!-- field-header ////// SHARED VIDEOS DISPLAY ///-->
                      <!-- <div class="field-spacer"></div> -->
                      <div id="sharedDisplay"></div>
											<!-- hidden field-header /////////////////////////-->
	                    <div class="field"><div class="unit">
	                        <textarea spellcheck="false" id="message" name="message" rows="40" style="display:none;"></textarea>
	                    </div></div>
                      <!-- hidden field-header /////////////////////////-->
                      <div class="field"><div class="unit">
                          <textarea spellcheck="false" id="libname" name="libname" rows="2" style="display:none;"></textarea>
                      </div></div>
                      <!-- checkbox field-header ///////////////////////-->
                      <div class="field"><div class="unit">
                        <fieldset>
                        <div class="field-header">Notificarme de nuevos videos de Hola401k
                        <div class="slide-chk right mt-8">
                          <input type="checkbox" id="notify" name="notify" value="I agree" checked="">
                          <label for="notify"></label>
                        </div>
                        </div>
                      <fieldset>
                      </div></div>
                      <!-- submit button //////////////////////////////-->
	                    <div class="field-spacer"></div>
	                    <div class="field"><div class="unit">
	                      <p class="submit"><input id="iSend" type="submit" value="Enviar mensaje"></p>
	                    </div></div>
                  </div><!-- /formActive -->
                      <!-- form response messages /////////////////////-->
	                    <div class="field"><div class="unit">
	                    <!-- start response from server -->
	                    <div id="response" class="init"></div>
	                    <!-- end response from server -->
	                    </div></div>
                      <!-- close shadowbox button /////////////////////-->
                      <!-- <div class="field-spacer"></div>
                      <div class="field"><div class="unit">
                        <p class="reset"><div id="iReset" onclick="parent.Shadowbox.close()"><i class="fa fa-window-close fa-3" aria-hidden="true" style="float:left;"></i> Close Share Form</div></p>
                      </div></div> -->
	                    </form>
	                    <!-- END FORM =================================================================================
	                    ============================================================================================ -->
									</div>    <!-- /container -->
	              </div>      <!-- /main -->
	            </section>    <!-- /milestones -->
				    </div>          <!-- /comments -->
	          <!-- END FORM WRAPPER and FORM -->

            <script>
              $( window ).load(function() {
                var ShareString = localStorage.getItem("BuiltString");
                var ShareDisplay = localStorage.getItem("BuiltDisplay");
                var ShareLibrary = localStorage.getItem("LibraryTitleFormal");
                //alert( ShareString );
                $( "#message" ).html( ShareString );
                $( "#sharedDisplay" ).html( ShareDisplay );
                $( "#libname" ).html( ShareLibrary );
              });
            </script>
            <script>
            $( "#iReset" ).mouseover(function() {
              $('#comments').removeClass( "idle" ).addClass( "closing" );
            });
            $( "#iReset" ).mouseout(function() {
              $('#comments').removeClass( "closing" ).addClass( "idle" );
            });
            $( "#close_button" ).mouseover(function() {
              $('#comments').removeClass( "idle" ).addClass( "closing" );
            });
            $( "#close_button" ).mouseout(function() {
              $('#comments').removeClass( "closing" ).addClass( "idle" );
            });
            $( "#iSend" ).click(function() {
              $('#response').removeClass( "init" ).addClass( "message" );
            });
            </script>


</body>
</html>
