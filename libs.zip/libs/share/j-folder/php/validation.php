<?php

/******************************************************/
/* Validation methods */
/******************************************************/
	/* Name */
	function validateName($name, $min_length) {
		$error_text = "Enter your name";
		$len = mb_strlen($name, 'UTF-8');
		return ($len < $min_length) ? $error_text : "valid";
	}

	/* Email */
	function validateEmail($email){
		$error_text = "Incorrect email format for sender";
		$email_template = "/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/";
		return (preg_match($email_template, $email) !== 1) ? $error_text : "valid";
	}

	/* SName */
	function validateSName($sname, $min_length) {
		$error_text = "Enter recipient's name";
		$slen = mb_strlen($sname, 'UTF-8');
		return ($slen < $min_length) ? $error_text : "valid";
	}

	/* SEmail */
	function validateSEmail($semail){
		$error_text = "Incorrect email format for recipient";
		$semail_template = "/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/";
		return (preg_match($semail_template, $semail) !== 1) ? $error_text : "valid";
	}

	/* Message */
	function validateComments($message, $min_length) {
		$error_text = "You have not selected any library videos to share. Close this form and select at least one video presentation.";
		$len = mb_strlen($message, 'UTF-8');
		return ($len < $min_length) ? $error_text : "valid";
	}
?>
