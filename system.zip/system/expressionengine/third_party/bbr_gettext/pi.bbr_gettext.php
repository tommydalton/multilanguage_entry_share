<?php
/**
 * Developed by Biber Ltd. (http://www.biberltd.com)
 *
 * version:         1.1.3
 * last update:     22 March 2011
 * author:          Can Berkol
 * copyright:       Biber Ltd. (http://biberltd.com)
 *
 * description:
 * This plugin can be used as a standalone application as well, but it makes mostly sense when
 * it is used alongside with Biber Ltd. Multi Language Support extension.
 *
 * This plugin enables you to read and return any language array key / value pair.
 *
 * license:
 *  -   You can copy and re-distribute this source code without removing any credits to original
 *      programmer: Biber Ltd.
 *  -   You may not sell or re-sell this source code as is within a package or individually.
 *  -   You can enhance and modify this source code without removing the original credits.
 *
 */
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$plugin_info = array(
    'pi_name'     => 'Biber Ltd. Get Text Plugin (for Multi Language Support)',
    'pi_version'  => '1.1.3',
    'pi_author'   => 'Biber Ltd',
    'pi_author_url'=>'http://www.biberltd.com/wiki/English:bbr_gettext/',
    'pi_description'=>'Returns the value of a language array key.',
    'pi_usage' => Bbr_gettext::usage()
);

class Bbr_gettext {
    public $return_data = '';
    public $language = 'auto';      /** If set to auto it tries to auto-detect the language.
 *  If detection fails, sets the language to English.
 */
    public $language_folder = 'tp';
    public $addon_name = 'bbr_multilanguagesupport';
    public $language_file = 'bbr_mysite';
    public $mode = 'exact';
    public $key = '';
    public $debug = 'off';
    private $prfx;
    private $folder_name = 'language';

    /**
     * Constructor
     *
     * @since       1.0.0
     * @date        16.07.2010
     * @author      Can Berkol
     *
     * PHP 5.0 & above
     */
    public function __construct(){
        $this->EE =& get_instance();
        $this->prfx = $this->EE->db->dbprefix;
        $this->return_data = $this->get_text();
    }
    function Bbr_gettext(){
        $this->__construct();
    }
    /**
     * Destructor
     *
     * @since       1.0.0
     * @date        16.07.2010
     * @author      Can Berkol
     *
     * PHP 5.0 & above
     */
    public function __destructor(){
        foreach($this as $property => $value){
            $this->$property = null;
        }
    }
    /**
     * get_text
     *
     * @since       1.0.0
     * @date        17.03.2011
     * @author      Can Berkol
     *
     * @version     1.1.2
     *
     * Gets the text.
     */
    private function get_text(){
        /**
         * Optional Parameters
         */
        if($this->EE->TMPL->fetch_param('language')){
            $this->language = $this->EE->TMPL->fetch_param('language');
        }
        if($this->EE->TMPL->fetch_param('debug')){
            $this->debug = $this->EE->TMPL->fetch_param('debug');
        }
        if($this->EE->TMPL->fetch_param('mode')){
            $this->mode = $this->EE->TMPL->fetch_param('mode');
        }
        if($this->EE->TMPL->fetch_param('language_folder')){
            $this->language_folder = $this->EE->TMPL->fetch_param('language_folder');
        }
        if($this->EE->TMPL->fetch_param('language_file')){
            $this->language_file = $this->EE->TMPL->fetch_param('language_file');
        }
        if($this->EE->TMPL->fetch_param('addon_name')){
            $this->addon_name = $this->EE->TMPL->fetch_param('addon_name');
        }
        /**
         * Required Parameters
         * If those do not exist we will return an error message.
         */
        if(!$this->EE->TMPL->fetch_param('key')){
            if($this->debug == 'on'){
                return 'ERROR :: BBRGTXT 0001 :: You must set the key
                        parameters when you call this plugin from within your templates.';
            }
            else{
                return FALSE;
            }
        }
        $this->key = $this->EE->TMPL->fetch_param('key');
        /**
         * Check if language folder is one of the available options.
         */
        $available_folders = array(BASEPATH => 'ci',
                                   APPPATH => 'ee',
                                   PATH_THIRD => 'tp');
        if(!in_array($this->language_folder, $available_folders)){
            if($this->debug == 'on'){
                return 'ERROR :: BBRGTXT 0002 :: Invalid language folder supplied. Available options are:<br />
                        ci, ee, tp';
            }
            else{
                return FALSE;
            }
        }
        /**
         *  Now it's time to build include path
         */
        $include_path = '';
        switch($this->language_folder){
            case 'tp':
                $include_path = PATH_THIRD.$this->addon_name.DIRECTORY_SEPARATOR.$this->folder_name.DIRECTORY_SEPARATOR;
                break;
            case 'ci':
                $include_path = BASEPATH.$this->folder_name.DIRECTORY_SEPARATOR;
                break;
            case 'ee':
                $include_path = APPPATH.$this->folder_name.DIRECTORY_SEPARATOR;
                break;
        }
        /**
         * Check folder.
         */
        if(!file_exists($include_path)){
            if($this->debug == 'on'){
                return 'ERROR :: BBRGTXT 0005 :: The folder does not
                    exist. Please check if the constructed path of the folder where your language file is
                    is expected to reside is valid: <br />'
                    .$include_path;
            }
            else{
                return FALSE;
            }
        }
        /**
         * Now select the language.
         */
        switch($this->language){
            case 'auto':
                /**
                 * NOTE: This works only with Biber Ltd. Multi Language Support Extension
                 */
                $language = '';
                $current_language = '';
                if(isset($this->EE->config->_global_vars['language'])){
                    $current_language = $this->EE->config->_global_vars['language'];
                }
                if(!empty($this->EE->session->userdata['language'])){
                    $language = $this->EE->session->userdata['language'];
                }
                else if(!empty($current_language)){
                    $language = $current_language;
                }
                else{
                    $language = 'english';
                }
                $include_path .= $language.DIRECTORY_SEPARATOR;
                break;
            default:
                $include_path .= $this->language.DIRECTORY_SEPARATOR;
                break;
        }
        /**
         *  Lastly we add the file name.
         */
        $filename = '';
        if($this->language_folder == 'ci' || $this->language_folder == 'ee'){
            $filename = $this->language_file.'_lang.php';
        }
        else{
            $filename = 'lang.'.$this->language_file.'.php';
        }
        $include_path .= $filename;
        /**
         * Does file exist?
         */
        if(!file_exists($include_path)){
            if($this->language_folder != 'bbr_multilanguagesupport' && $this->language_file != 'bbr_mysite'){
                if($this->debug == 'on'){
                    return 'ERROR :: BBRGTXT 0004 :: The language file '.$this->language_file.' does not
                        exist. Please check if the constructed path is valid: <br />'
                        .$include_path;
                }
                else{
                    return FALSE;
                }
            }
            else{
                $query = 'SELECT settings FROM '.$this->prfx.'extensions WHERE class = "Bbr_multilanguagesupport_ext" LIMIT 1';
                $result = $this->EE->db->query($query);
                $settings = unserialize($result->row('settings'));
                $texts = unserialize(base64_decode($settings['texts']));
                foreach($texts as $text){
                    if($text['key'] == $this->key){
                        return $text[$language];
                    }
                }
                return '';
            }
        }
        include($include_path);
        if((!isset($lang) || !is_array($lang)) && (!isset($lang_bbr) || !is_array($lang_bbr))){
            if($this->debug == 'on'){
                return 'ERROR :: BBRGTXT 0006 :: $lang array does not exist. Make sure if your language file
                        is set correctly and if it does match to Expression Engine 2.0 coding standards.'
                    .$include_path;
            }
            else{
                return FALSE;
            }
        }
        $key = $this->key;
        if($this->mode == 'lowercase'){
            $key = strtolower($this->key);
        }
        else if($this->mode == 'uppercase'){
            $key = strtoupper($this->key);
        }
        if($this->language_file == 'core'){
            echo $key.'-';
        }
        if(isset($lang[$key])){
            return $lang[$key];
        }
        if(isset($lang_bbr[$key])){
            return $lang_bbr[$key];
        }
        return FALSE;
    }
    /**
     * usage
     *
     * @since       1.0.0
     * @date        16.07.2010
     * @author      Can Berkol
     *
     * Shows usage information in plugin control panel.
     */
    public static function usage(){
        ob_start();
        ?>
        Although it can be used as a stand-alone plugin; this plugin is intended to be used with Biber Ltd. Multi Language Support extension. Therefore some functions such as auto-detecting the current user language will not function correctly without the Multi Language Support extension.

        With this plugin you can output any text from within your language files without enabling PHP in your templates.

        The plugin can read both CodeIgniter system language files, Expression Engine 2.0 core language files and Third Party Add-On language files.

        The plugin accepts five parameters:

        - language          optional. Defines in which language you want to get the text.

        If used with Biber Ltd. Multi Language Support extension; there is no need to

        use this parameter because the user language will be detected automatically.

        Otherwise you are required to include this parameter for the plugin to work as

        expected. Note: the value must equal to your language folder.


        - language_folder   required. This defines the location of language file that is requested.


        This parameter accepts one of the three values:

        - tp :      for Third Party Language Files

        - ee :      for Expression Engine 2.0 Core Language Files

        - ci :      for CodeIgniter System Language Files


        - addon_name        optional. Defines the third party addon folder name.


        This parameter is only required if you set language_folder to "tp". The value

        must be equal to the addon's folder name.


        - language_file     optional. This is absolutely required except if you want to get  translations from
        Multi Language Extensions standard translation files; however keep in mind that you have
        to set "Storage Engine" to "File" in order to use this with Multi Lanaguage Extension.


        Here you need to enter the file name with out ".php", "lang." and "_lang"

        pre-and-postfixes.


        - key               required. This defines the array key - which text within the language file.


        EXAMPLES:



        Get Turkish value for htaccess_written_successfully from lang.blacklist.php



        {exp:bbr_gettext language="turkish" language_folder="ee" language_file="blacklist" key="htaccess_written_successfully"}



        Get value for htaccess_written_successfully from lang.blacklist.php for the current user's language (auto detect)



        {exp:bbr_gettext language_folder="ee" language_file="blacklist" key="htaccess_written_successfully"}



        Get the third party extension's (i.e. Biber Ltd. Multi Language Support) value for hdn-options for the current user's language.



        {exp:bbr_gettext language_folder="tp" addon_name="bbr_multilanguage_support" language_file="bbr_multilanguage_support" key="hdn-options"}

        <?php

        $buffer = ob_get_contents();


        ob_end_clean();


        return $buffer;

    }

    // END

}


/* End of file pi.bbr_gettext.php */

/* Location: ./system/expressionengine/third_party/bbr_multilanguagesupport/pi.bbr_gettext.php */

?>
