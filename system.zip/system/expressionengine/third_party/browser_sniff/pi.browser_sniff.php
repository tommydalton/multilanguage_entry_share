<?php
/*
=====================================================
 This ExpressionEngine plugin was created by Laisvunas
 - http://devot-ee.com/developers/ee/laisvunas/
=====================================================
 Copyright (c) Laisvunas
=====================================================
 This is commercial Software.
 One purchased license permits the use this Software on the SINGLE website.
 Unless you have been granted prior, written consent from Laisvunas, you may not:
 * Reproduce, distribute, or transfer the Software, or portions thereof, to any third party
 * Sell, rent, lease, assign, or sublet the Software or portions thereof
 * Grant rights to any other person
=====================================================
 Purpose: Allows to get information about the browser, mobile device, or robot visiting your site.
=====================================================
*/

$plugin_info = array(
						'pi_name'			=> 'Browser Sniff',
						'pi_version'		=> '2.4',
						'pi_author'			=> 'Laisvunas',
						'pi_author_url'		=> 'http://devot-ee.com/developers/ee/laisvunas/',
						'pi_description'	=> 'Allows to get information about the browser, mobile device, or robot visiting your site.',
						'pi_usage'			=> browser_sniff::usage()

					);

class Browser_sniff {

  var $return_data = '';

  function Browser_sniff()
  {
    $this->EE =& get_instance();

    // Fetch the tagdata
		  $tagdata = $this->EE->TMPL->tagdata;

    // fetch parameters
    $available_languages = $this->EE->TMPL->fetch_param('available_languages') ? explode('|', $this->EE->TMPL->fetch_param('available_languages')) : array();

    // Define variables
    $conds = array();

    // Load User Agent library
    $this->EE->load->library('user_agent');
    $this->EE->load->library('uagent_info');

    $conds['browser_sniff_is_browser'] = $this->EE->agent->is_browser() ? 'yes' : 'no';

    $conds['browser_sniff_is_mobile'] = $this->EE->agent->is_mobile() ? 'yes' : 'no';

    $conds['browser_sniff_is_robot'] = $this->EE->agent->is_robot() ? 'yes' : 'no';

    $conds['browser_sniff_is_referral'] = $this->EE->agent->is_referral() ? 'yes' : 'no';

    $conds['browser_sniff_browser'] = $this->EE->agent->browser();

    $conds['browser_sniff_version'] = $this->EE->agent->version();

    $conds['browser_sniff_mobile'] = $this->EE->agent->mobile();

    $conds['browser_sniff_robot'] = $this->EE->agent->robot();

    $conds['browser_sniff_platform'] = $this->EE->agent->platform();

    $conds['browser_sniff_referrer'] = $this->EE->agent->referrer();

    $conds['browser_sniff_agent_string'] = $this->EE->agent->agent_string();

    if (strpos(strtolower($conds['browser_sniff_agent_string']), 'windows') !== FALSE)
    {
      $conds['browser_sniff_platform_shortname'] = 'Win';
    }
    elseif (strpos(strtolower($conds['browser_sniff_agent_string']), 'macintosh') !== FALSE)
    {
      $conds['browser_sniff_platform_shortname'] = 'Mac';
    }
    elseif (strpos(strtolower($conds['browser_sniff_agent_string']), 'linux') !== FALSE)
    {
      $conds['browser_sniff_platform_shortname'] = 'Linux';
    }
    else
    {
      $conds['browser_sniff_platform_shortname'] = 'Other';
    }

    // detect specific devices
    $conds['browser_sniff_detect_ipad'] = $this->EE->uagent_info->DetectIpad() ? 'yes' : 'no';
    $conds['browser_sniff_detect_iphone'] = $this->EE->uagent_info->DetectIphone() ? 'yes' : 'no';

    // detect classes of devices
    $conds['browser_sniff_detect_smartphone'] = $this->EE->uagent_info->DetectSmartphone() ? 'yes' : 'no';
    $conds['browser_sniff_detect_mobilequick'] = $this->EE->uagent_info->DetectMobileQuick() ? 'yes' : 'no';
    $conds['browser_sniff_detect_mobilelong'] = $this->EE->uagent_info->DetectMobileLong() ? 'yes' : 'no';
    $conds['browser_sniff_detect_gameconsole'] = $this->EE->uagent_info->DetectGameConsole() ? 'yes' : 'no';

    // detect device tiers
    $conds['browser_sniff_detect_tiertablet'] = $this->EE->uagent_info->DetectTierTablet() ? 'yes' : 'no';
    $conds['browser_sniff_detect_tieriphone'] = $this->EE->uagent_info->DetectTierIphone() ? 'yes' : 'no';
    $conds['browser_sniff_detect_tierrichcss'] = $this->EE->uagent_info->DetectTierRichCss() ? 'yes' : 'no';
    $conds['browser_sniff_detect_tierotherphones'] = $this->EE->uagent_info->DetectTierOtherPhones() ? 'yes' : 'no';

    // output negotiated language
    if (strpos($tagdata, 'browser_sniff_negotiated_language') !== FALSE) // check if variable "browser_sniff_negotiated_language" is present
    {
      if (count($available_languages) == 0)
      {
        echo 'ERROR! In order to use "browser_sniff_negotiated_language" variable of exp:browser_sniff tag you must define "available_languages" parameter of this tag.<br><br>';
      }
      elseif (function_exists('http_negotiate_language'))
      {
        $conds['browser_sniff_negotiated_language'] = http_negotiate_language($available_languages);
      }
      else
      {
        $conds['browser_sniff_negotiated_language'] = browser_sniff_negotiate_language($available_languages);
      }
    }

    // Prepare conditionals
    $tagdata = $this->EE->functions->prep_conditionals($tagdata, $conds);

    // Output variables
    foreach ($conds as $key => $value)
    {
      //echo '$conds['.$key.']: ['.$value.']<br><br>';
      $tagdata = $this->EE->TMPL->swap_var_single($key, $value, $tagdata);
    }

    return $this->return_data = $tagdata;
  }

  // ----------------------------------------
  //  Plugin Usage
  // ----------------------------------------
  // This function describes how the plugin is used.
  //  Make sure and use output buffering

  public static function usage()
  {
    ob_start();
?>

PARAMETERS

1) available_languages - optional. Pipe delimited list of site's languages. The value of this parameter
will be used to output the value of the variable "browser_sniff_negotiated_language". E.g. available_languages="fi|en" ,
"en" means English and "fi" means Finnish. The language code can be followed by a hyphen and then a two-character country code.
For example, "en-us" means American English and "en-gb" means British English. The first language code should indicate default language
of the website.

VARIABLES

1) browser_sniff_is_browser - outputs "yes" if the user agent is a known web browser and "no" otherwise.

2) browser_sniff_is_mobile - outputs "yes" if the user agent is a known mobile device and "no" otherwise.

3) browser_sniff_is_robot - outputs "yes" if the user agent is a known robot and "no" otherwise.

4) browser_sniff_is_referral - outputs "yes" if the user agent was referred from another site and "no" otherwise.

5) browser_sniff_browser - outputs a string containing the name of the web browser viewing your site.

6) browser_sniff_version - outputs a string containing the version number of the web browser viewing your site.

7) browser_sniff_mobile - outputs a string containing the name of the mobile device viewing your site.

8) browser_sniff_robot - outputs a string containing the name of the robot viewing your site.

9) browser_sniff_platform - outputs a string containing name of the platform viewing your site (Linux, Windows, OS X, etc.).

10) browser_sniff_platform_shortname - outputs a string containing short name of the platform viewing your site.
Possible values for this variable are: "Win", "Mac", "Linux" and "Other".

11) browser_sniff_referrer - outputs referrer, if the user agent was referred from another site.

12) browser_sniff_agent_string - outputs a string containing the full user agent string.

To detect classes of mobile devices use the following variables. Use these variables to detect broad classes of mobile devices,
excluding the Apple iPad. However, for developing mobile-optimized web design, we recommend using the Device Tier variables.

13) browser_sniff_detect_smartphone - possible values "yes" and "no". Detects any kind of smartphone device.
This variable doesn’t take into account browser capabilities.

14) browser_sniff_detect_mobilequick - possible values "yes" and "no". Detects most recent mobile phones.

15) browser_sniff_detect_mobilelong - possible values "yes" and "no". Detects most mobile phones,
including some older phones, and game consoles.

16) browser_sniff_detect_gameconsole - possible values "yes" and "no". Detects all of the gaming consoles.

To detect groups of mobile devices based on  capabilities of their browsers of their browsers use the
following variables.

17) browser_sniff_detect_tiertablet - possible values "yes" and "no". These have larger screens
 and their browsers are HTML 5-capable. These browsers handle CSS and JavaScript very well,
 which means that modest AJAX sites with native (iPad or other) style components typically work great.
 Includes: iPad, Android tablets (e.g., Xoom), BlackBerry PlayBook, WebOS, etc.

18) browser_sniff_detect_tieriphone - possible values "yes" and "no". These are modern touchscreen  phones.
These browsers handle CSS and JavaScript very well, which means that modest AJAX sites with native
(iPhone or other) style components typically work great.

19) browser_sniff_detect_tierrichcss - possible values "yes" and "no". These devices can handle CSS
reasonable well, so that iPhone- or Android-style UIs generally look fine. Unfortunately, JavaScript
support is poor. For these reasons, in most cases, it’s probably best to serve these devices
the generic mobile site rather than the iPhone Tier site.

20) browser_sniff_detect_tierotherphones - possible values "yes" and "no". Detects for all other mobile devices,
excluding the iPhone or Rich CSS tier devices. For these devices, it’s best to serve only the most basic CSS style,
limited to little more than text color, alignment, and bold/italics.

NOTICE: To best use the device tier detection, you might optimize your device detection logic like this:

{exp:browser_sniff}

{if browser_sniff_detect_tiertablet == "yes"}

Some code for tablet optimized version of the site.

{if:elseif browser_sniff_detect_tieriphone == "yes"}

Some code for iPhone/Android/etc. optimized version of the site.

{if:elseif browser_sniff_detect_mobilequick == "yes"}

Some code for  the general mobile site with minimal CSS and no JavaScript.

{if:else}

Some code for modern desktop browser version of the site.

{/if}

{/exp:browser_sniff}

21) browser_sniff_negotiated_language - outputs the browser's preferred language based on Accept-Language HTTP header.
For this variable to work the parameter "available_languages" must be defined. Also for this variable to work PHP
extension "pecl_http" available for free at http://pecl.php.net/package/pecl_http must be installed.

Conditionals are supported for all variables.

NOTICE. Use browser_sniff_negotiated_language variable as in this example (first language in pipe delimited list is default site’s language):

{exp:browser_sniff available_languages="fi|se|en"}

{if browser_sniff_negotiated_language == "se"}

here goes content for Swedish speakers

{if:elseif browser_sniff_negotiated_language == "en"}

here goes content for English speakers

{if:else}

here goes default content in Finnish

{/if}

{/exp:browser_sniff}

22) browser_sniff_detect_ipad - possible values "yes" and "no". Detects iPad.

23) browser_sniff_detect_iphone - possible values "yes" and "no". Detects iPhone.


USAGE EXAMPLE

{exp:browser_sniff}

Is browser?: {browser_sniff_is_browser}<br>

Is mobile?: {browser_sniff_is_mobile}<br>

Is robot?: {browser_sniff_is_robot}<br>

Is iPad?:  {browser_sniff_detect_ipad}<br>

Is iPhone?:  {browser_sniff_detect_iphone}<br>

Is referral: {browser_sniff_is_referral}<br>

Browser name: {browser_sniff_browser}<br>

Browser version: {browser_sniff_version}<br>

Mobile device name: {browser_sniff_mobile}<br>

Robot name: {browser_sniff_robot}<br>

Platform name: {browser_sniff_platform}<br>

Platform shortname: {browser_sniff_platform_shortname}<br>

Referrer: {browser_sniff_referrer}<br>

User agent string: {browser_sniff_agent_string}<br>

{/exp:browser_sniff}


<?php
    $buffer = ob_get_contents();
    ob_end_clean();
    return $buffer;
  }
  // END FUNCTION
}
// END CLASS

function browser_sniff_negotiate_language($available_languages)
{
  //var_dump($available_languages); echo '<br><br>';

  if (isset($_SERVER['HTTP_ACCEPT_LANGUAGE'])) {
    // break up string into pieces (languages and q factors)
    preg_match_all('/([a-z]{1,8}(-[a-z]{1,8})?)\s*(;\s*q\s*=\s*(1|0\.[0-9]+))?/i', $_SERVER['HTTP_ACCEPT_LANGUAGE'], $lang_parse);

    if (count($lang_parse[1])) {
      // create a list like "en" => 0.8
      $langs = array_combine($lang_parse[1], $lang_parse[4]);

      // set default to 1 for any without q factor
      foreach ($langs as $lang => $val) {
          if ($val === '') $langs[$lang] = 1;
      }

      // sort list based on value
      arsort($langs, SORT_NUMERIC);
      $langs = array_keys($langs);
      //var_dump($langs); echo '<br><br>';

      foreach ($available_languages as $lang)
      {
        if (in_array($lang, $langs))
        {
          //var_dump($lang); echo '<br><br>';
          return $lang;
        }
      }
    }
  }
}
// END FUNCTION
?>
