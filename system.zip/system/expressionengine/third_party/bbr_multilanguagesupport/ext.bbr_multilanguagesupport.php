<?php
/**
 * Developed by Biber Ltd. (http://www.biberltd.com)
 * 
 * version:         2.2.2
 * last update:     09 Seotember 2012
 * author:          Can Berkol
 * copyright:       Biber Ltd. (http://biberltd.com)
 * 
 * description:
 * This is an extension developed for ExpressionEngine 2.0. It brings ExpressionEngine 
 * front-end (where your visitors access to the site) the multi language support.
 * 
 * Currently, out of the package ExpressionEngine 2.0 does not let you or your visitors
 * switch languages of your site. With the aid of this extension and a few structural changes
 * in your existing templates, you can make your web site throughly multi-lingual.
 * 
 * license:
 * 
 * This license is a legal agreement between you and Biber Bilisim Teknolojileri ve Dis Tic. Ltd. Sti
 * (Biber Ltd.) for the use of our add-ons and other software (the “Software”). 
 * By downloading any Biber Ltd. software you agree to be bound by the terms and conditions of this 
 * license. Biber Ltd. reserves the right to alter this agreement at any time, for any reason, without 
 * notice.
 * 
 * PERMITTED USE
 * 
 * One license grants the right to perform one installation of the Software. Each additional 
 * installation of the Software requires an additional purchased license. Development systems 
 * are not included in these restrictions, you may install the Software on development systems 
 * as needed.
 * 
 * RESTRICTIONS
 * 
 * Unless you have been granted prior, written consent from Biber Ltd., you may not:
 * 
 *      Reproduce, distribute, or transfer the Software, or portions thereof, to any third party.
 *      Sell, rent, lease, assign, or sublet the Software or portions thereof.
 *      Grant rights to any other person.
 *      Use the Software in violation of any laws of the Republic of Turkiye or international 
 *      law or regulation.
 * 
 * DISPLAY OF COPYRIGHT NOTICES
 * 
 * All copyright and proprietary notices and logos in the Control Panel and within the Software 
 * files must remain intact.
 * 
 * MAKING COPIES
 * 
 * You may make copies of the Software for back-up purposes, provided that you reproduce the 
 * Software in its original form and with all proprietary notices on the back-up copy.
 * 
 * SOFTWARE MODIFICIATIONS
 * 
 * You may alter, modify, or extend the Software for your own use, or commission a third-party 
 * to perform modifications for you, but you may not resell, redistribute or transfer 
 * the modified or derivative version without prior written consent from Biber Ltd. Components 
 * from the Software may not be extracted and used in other programs without prior written consent 
 * from Biber Ltd.
 * 
 * TECHNIOCAL SUPPORT
 * 
 * Technical support is available through emailing Software Support at support@biberltd.com. 
 * Biber Ltd. does not provide direct phone support. No representations or guarantees are made 
 * regarding the response time in which support questions are answered.
 * 
 * REFUNDS
 * 
 * Biber Ltd. offers refunds on software within 15 days of purchase. All transaction fees will 
 * be deducted before refund is applied. Send a refund request for assistance.
 * 
 * INDEMNITY
 * 
 * You agree to indemnify and hold harmless Biber Ltd. for any third-party claims, actions or suits, 
 * as well as any related expenses, liabilities, damages, settlements or fees arising from your use 
 * or misuse of the Software, or a violation of any terms of this license.
 * 
 * DISCLAIMER OF WARRANTY
 * 
 * THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESSED OR IMPLIED, INCLUDING, 
 * BUT NOT LIMITED TO, WARRANTIES OF QUALITY, PERFORMANCE, NON-INFRINGEMENT, MERCHANTABILITY, OR 
 * FITNESS FOR A PARTICULAR PURPOSE.  FURTHER, BIBER LTD DOES NOT WARRANT THAT THE SOFTWARE OR 
 * ANY RELATED SERVICE WILL ALWAYS BE AVAILABLE.
 * 
 * LIMITIATIONS OF LIBRARY
 * 
 * YOU ASSUME ALL RISK ASSOCIATED WITH THE INSTALLATION AND USE OF THE SOFTWARE. IN NO EVENT SHALL 
 * THE AUTHORS OR COPYRIGHT HOLDERS OF THE SOFTWARE BE LIABLE FOR CLAIMS, DAMAGES OR OTHER LIABILITY
 * ARISING FROM, OUT OF, OR IN CONNECTION WITH THE SOFTWARE. LICENSE HOLDERS ARE SOLELY RESPONSIBLE 
 * FOR DETERMINING THE APPROPRIATENESS OF USE AND ASSUME ALL RISKS ASSOCIATED WITH ITS USE, INCLUDING 
 * BUT NOT LIMITED TO THE RISKS OF PROGRAM ERRORS, DAMAGE TO EQUIPMENT, LOSS OF DATA OR SOFTWARE 
 * PROGRAMS, OR UNAVAILABILITY OR INTERRUPTION OF OPERATIONS.
 * 
 * 
 * It is hereby understood that the downloading of any Biber Ltd.software automatically binds you to 
 * all the terms of this Software License Agreement.
 * 
 */ 
 
// if ( ! defined('EXT')) { exit('Invalid file request'); }

class Bbr_multilanguagesupport_ext {
    
    public $settings        = array(); 
    public $name            = 'Biber Ltd. Multi Language Support v2.2.3';
    public $version         = '2.2.3';
    public $description     = 'Provides multi-language support to front end.';
    public $settings_exist  = 'y';
    public $docs_url        = 'http://biberltd.com/wiki/English:multi_language_support2/';
    
    private $site_id        = 1;
    private $sysdir = '';
    private $dm = '';
    private $EE;            /** We will set EE instance here */
    private $prfx;          /** db prefix */
    private $dd;
    
    /**
     * Constructor
     * 
     * @since       1.0.0
     * @date        10.07.2010
     * @author      Can Berkol
     * 
     * PHP 5.0 & above
     */ 
    public function __construct($settings = ''){
        $this->EE =& get_instance();
        $this->prfx = $this->EE->db->dbprefix;
        $this->dd = DIRECTORY_SEPARATOR;
        $this->settings = $settings;

        /**
         * set current site_id
         */ 

        $this->site_id = $this->EE->config->config['site_id'];
    }
    /**
     * Destructor
     * 
     * @since       1.0.0
     * @date        10.07.2010
     * @author      Can Berkol
     * 
     * PHP 5.0 & above
     */ 
    public function __destructor(){
        foreach($this as $property => $value){
            $this->$property = null;
        }
    }
    /**
     * Constructor
     * 
     * @since       1.0.0
     * @date        10.07.2010
     * @author      Can Berkol
     * 
     * This function exists for compatibility reasons.
     */ 
    public function Bbr_multilanguagesupport_ext($settings=''){
        $this->__construct($settings);
    }
    /**
	 * activate_extension()
	 *
     * @since       1.0.0
     * @date        10.07.2010
     * @author      Can Berkol
     * @version     1.0.7
     * 
     * Activates the extension.
	 */
	public function activate_extension(){
        /**
         *  Set up hook & function pairs.
         * 
         *  i.e. 'hook_name' => 'function_name'
         */ 
		$hooks = array(
			'sessions_start' => 'switch_language',
            'channel_entries_tagdata' => 'auto_translate_fields'
        //    'channel_entries_tagdata_end' => 'auto_translate_fields_end'
		);
        /**
         * Prepare default settings
         */ 
        $this->settings['default_language_mode'] = 'browser';
        $this->settings['default_language'] = 'english';
        $this->settings['available_lang'] = array('English');
        $this->settings['available_lang_code'] = array('en');

        /** Build sql statements for each of the hook & function pairs */
        $ext_data = '';
		foreach ($hooks as $hook => $function){
			$ext_data = array('class'		 => get_class($this),
                              'method'       => $function,
                              'hook'		 => $hook,
                              'settings'	 => serialize($this->settings),
                              'priority'	 => 1,
                              'version'		 => $this->version,
                              'enabled'		 => 'y'
                              );
             $this->EE->db->insert($this->prfx.'extensions', $ext_data);
		}
		return TRUE;
	}
 	/**
	 * update_extension()
 	 *
     * @since       1.0.0
     * @date        10.07.2010
     * @author      Can Berkol
     * 
     * Updates the extension.
     * 
     * @param   string      $latest      the latest version number.
	 * @return	bool FALSE if the extension is not installed or is the current version
	 */
	public function update_extension($latest = ''){
		if ($latest == '' OR $latest == $this->version){
			return FALSE;
		}
        $data = array('version' => $this->version);
        switch($latest){
            case '2.1.3':
                break;
            case '2.1.2':
            case '2.1.1':
            case '2.1.0':
            case '2.0.9':
            case '2.0.8':
            case '2.0.7':
            case '2.0.6':
            case '2.0.5':
            case '2.0.4':
            case '2.0.3':
            case '2.0.2':
            case '2.0.1':
            case '2.0.0':
                /**
                 * First update the hook
                 */ 
                $query = 'UPDATE '.$this->prfx.'extensions SET hook = "sessions_start" WHERE '.
                         'class = "Bbr_multilanguagesupport_ext" AND method = "switch_language" AND '.
                         'hook = "sessions_end"';
                $this->EE->db->query($query);
                /**
                 * Now copy language files and folders to themes/third_party/bbr_multilanguagesupport/language/
                 */
                $old_folder = PATH_THIRD.'bbr_multilanguagesupport'.$this->dd.'language';
                $new_location = PATH_THEMES.'third_party'.$this->dd.'bbr_multilanguagesupport'.$this->dd.'language';
                $this->copy_recursive($old_folder, $new_location);
                /**
                 * For backup purposes we have chosen not to delete the old files.
                 */ 
                break;
            default:
                break;
        }
        $this->EE->db->where('class', get_class($this))->update($this->prfx.'extensions', $data);
	}

 	/**
	 * disable_extension()
 	 *
     * @since       1.0.0
     * @date        11.08.2010
     * @author      Can Berkol
     * @version     1.1.0
     * 
     * Disables the extension.
	 */
	public function disable_extension(){
	    /**
         * We also need to delete auto created files & folders.
         */
        $current_settings = $this->retrieve_settings();
        $available_language_codes = $current_settings['available_lang_code'];
        $fcpath = FCPATH;
        $fcfile = 'index.php';
        $rootpath = $this->get_root_path($fcfile);      
        $fullpath = $rootpath.$fcfile;
        foreach($available_language_codes as $folder){
            if($folder != '' && file_exists($rootpath.$folder.$this->dm)){
                $this->rmdir_recursive($rootpath.$folder.$this->dm);
            }      
        }
        /**
         *  Now it's time to remove DB entry
         */ 
        $this->EE->db->where('class', get_class($this))->delete($this->prfx.'extensions');
    }
    /**
	 * auto_translate_fields()
 	 *
     * @since       2.1.0
     * @date        10.03.2010
     * @author      Can Berkol
     * 
     * Switches language.
	 */
	private function get_field_id($field_name, $site_id){
	   if(empty($site_id) || !is_numeric($site_id)){
            return '';
        }
        $query = 'SELECT field_id, field_type, field_content_type FROM '.$this->prfx.'channel_fields WHERE field_name = "'.$field_name.'" AND site_id = '.$site_id;
        $result = $this->EE->db->query($query);
        if($result->num_rows() > 0){
            $this->field_type = $result->row('field_type');
            $this->field_content_type = $result->row('field_content_type');
            return $result->row('field_id');
        }
        return FALSE;
    }
    /**
	 * auto_translate_fields()
 	 *
     * @since       2.1.0
     * @date        10.03.2010
     * @author      Can Berkol
     * 
     * Loads custom field translations automatically.
	 */
	public function auto_translate_fields($tagdata, $row, $channel){
	   if($this->EE->extensions->last_call != '' && $this->EE->extensions->last_call != FALSE){
	       $tagdata = $this->EE->extensions->last_call;
	   }
       $matches = array();
       $translations = array();
       /**
        * Get language code related details for translation switching mechanism
        */ 
       $language_codes = $this->settings['available_lang_code'];
       $default_language_code = $this->EE->config->_global_vars['default_language_code'];
       $current_language_code = $this->EE->config->_global_vars['language_code'];
       /**
        * Get auto translatable fields, if there are any
        */ 
       if(preg_match_all("/".LD.'bbr-mls:.*?'.RD."/", $tagdata, $all_matches)){
           /**
             * Prepare translations array
            */ 
           foreach($language_codes as $code){
                $translations[$code] = '';
           }
           /**
            * Set the translations.
            * 
            * Note translations are set in two different ways depending of the field name. If a field is a 
            * standart field we do something, and if the field is a custome field we do something else.
            * 
            * If there is no translation found for given language, then the translation for the default
            * language will be outputted.
            * 
            * If there is no default translation either then an empty string will be outputted.
            */ 
           $matches = array();

           if(isset($all_matches[0]) && !empty($all_matches[0])){
                $matches = $all_matches[0];
           }

           foreach($matches as $match){
               $field_name = rtrim(ltrim(str_replace('bbr-mls:', '', $match),'{'), '}');
               if(!isset($row[$field_name])){
                    foreach($language_codes as $code){
                        $field_id = $this->get_field_id($field_name.'_'.$code,  $this->EE->config->_global_vars['site_id']);
                        if(!$field_id){
                            $translations[$code] = ''; 
                        }
                        else{
                            $translations[$code] = $row['field_id_'.$field_id];
                        }
                    }
               }
               else{
                    $translations[$default_language_code] = $row[$field_name];
                    foreach($language_codes as $code){
                        if($code != $default_language_code){
                            $field_id = $this->get_field_id($field_name.'_'.$code,  $this->EE->config->_global_vars['site_id']);
                            if(!$field_id){
                                $translations[$code] = ''; 
                            }
                            else{
                                $translations[$code] = $row['field_id_'.$field_id];
                            }
                        }
                    }
               }
               if(isset($translations[$current_language_code]) && !empty($translations[$current_language_code])){
                    $tagdata = str_replace($match, $translations[$current_language_code], $tagdata);
               }
               else{
                    $tagdata = str_replace($match, $translations[$default_language_code], $tagdata);
               }                                             
           }              
	   }
       return $tagdata; 
    }

    /**
	 * auto_translate_fields_end()
 	 *
     * @since       2.1.4
     * @date        31.03.2010
     * @author      Neil Evans
     * 
     * Loads custom field translations automatically.
     * Necessaey
	 */
    public function auto_translate_fields_end($tagdata, $row, $channel){
        // Setup Some Variables
        $matches = array();
        $translations = array();
        
        // Get language code related details for translation switching mechanism
        $language_codes         = $this->settings['available_lang_code'];
        $default_language_code     = $this->EE->config->_global_vars['default_language_code'];
        $current_language_code     = $this->EE->config->_global_vars['language_code'];
        $current_language         = $this->EE->config->_global_vars['language'];

        // Get auto translatable fields, if there are any
        if(preg_match_all("/".LD.'bbr-mls-out-.*'.RD."/", $tagdata, $matches)){    

            // Getting the settings values saved in the extensions.
            $settings = $this->retrieve_settings();
            
            // Get the translations from DB or File
            if($settings['store_engine'] == 'db'){
                // Only if they are saved in the settings
                if(isset($settings['texts'])){
                    $decoded_text = base64_decode(unserialize($settings['texts']));
                    // So... Lets create the default translation array for the correct language only
                    foreach($decoded_text as $texts){
                        $translation[$texts['key']] = htmlspecialchars_decode($texts[$current_language], ENT_NOQUOTES);
                    }
                }
            }
            else{
                // Only if the actual language files exist
                if(file_exists($file_path)){

                    // So... Lets create the default translation array for the correct language only
                    include($file_path);
                    foreach($lang_bbr as $key => $value){
                        $translation[$texts['key']] = htmlspecialchars_decode($value, ENT_NOQUOTES);
                    }
                }
            }
            // Now some translation fun and games
            foreach($matches['0'] as $match){
                // Trim off the wrapping tag bits...
                $field_name = rtrim(ltrim(str_replace('bbr-mls-out-', '', $match),'{'), '}');           
                if(isset($translation[$field_name]) && !empty($translation[$field_name])){
                    $tagdata = str_replace($match, $translation[$field_name], $tagdata);
                }
                else{
                    $tagdata = str_replace($match, 'no-translation-error-sorry', $tagdata);
                }
            }
        }
        return $tagdata; 
    }  
    /**
	 * switch_language()
	 *
     * @since       1.0.0
     * @date        22.10.2010
     * @author      Can Berkol
     * 
     * @version     2.0.0
     * 
     * Switches language.
	 */
	public function switch_language(&$session){
	   /**
        *  Retrieve extension settings
        */
       $settings = $this->retrieve_settings();
       $cookie_expiration = time() + 259200;
       /**
        * Make languages and language codes easier to handle
        */
       $available_languages = $settings['available_lang'];
       $available_language_codes = $settings['available_lang_code'];
       $available_language_aliases = array();

       if(isset($settings['available_lang_alias'])){
        $available_language_aliases = $settings['available_lang_alias'];
       }
       
       $default_mode = $settings['default_language_mode'];
       $count = 0;
       $languages = array();
       $language_aliases = array();

       foreach($available_language_codes as $language_code){
           $languages[$language_code] = strtolower($available_languages[$count]);
           if(isset($language_aliases[$language_code])){
                $language_aliases[$language_code] = $available_language_aliases[$count];
           }
           else{
                $language_aliases[$language_code] = '';
           }
           $count++;
       }

       $default_language = $settings['default_language'];
       $temp = array_keys($languages, $default_language);
       $default_language_code = $temp[0];
       $default_language_alias = $language_aliases[$temp[0]];

       $this->EE->config->_global_vars['default_language'] = $default_language;
       $this->EE->config->_global_vars['default_language_code'] = $default_language_code;
       $this->EE->config->_global_vars['default_language_alias'] = $default_language_alias;

       /**
        *  Collect all the data we will refer later on
        */
       $is_loggedin = FALSE;

       if(!empty($session->userdata['username'])){
            $is_loggedin = TRUE;
       }

       /**
        * Logged-in user settings
        */ 

       $user_language = '';
       $user_language_code = '';

       if(!empty($session->userdata['language'])){
           $user_language = strtolower($session->userdata['language']);
           $temp = array_keys($languages, $user_language);        
           if(count($temp) == 0){
                $temp[0] = 'en';
           }

           $user_language_code = $temp[0];
           $user_language_alias = $language_aliases[$temp[0]];
       }

       /**
        * Cookie stored settings
        */
       $cookie_language = $this->EE->input->cookie('language');
       $cookie_language_code = $this->EE->input->cookie('language_code');
       $cookie_language_alias = $this->EE->input->cookie('language_alias');

       /**
        * System defaults
        */  
       $system_language = strtolower($settings['default_language']);
       $temp = array_keys($languages, $system_language);    
       $system_language_code = $temp[0];
       $system_language_alias= $language_aliases[$temp[0]];

       /**
        * Current language as stored in global vars!
        */

       if(isset($this->EE->config->_global_vars['language']) && isset($this->EE->config->_global_vars['language_code']) && isset($this->EE->config->_global_vars['language_alias'])){
            $current_language = $this->EE->config->_global_vars['language'];
            $current_language_code = $this->EE->config->_global_vars['language_code'];
            $current_language_alias = $this->EE->config->_global_vars['language_alias'];
       }
       else{
            $current_language = '';
            $current_language_code = '';
            $current_language_alias = '';
       }

       /**
        * Now it's time to do some checks and set the language.
        * 
        * Do not forget! Here the current language and therefore the _global_vars, cookie_language and others must be initialized.
        */ 

       if($is_loggedin){
            /**
             * For some reason if both user_language and current_language are empty
             * we need to set both to default language.
             * 
             * If user_language is empty but the current language is not then we need to assign current language to user language
             * 
             * If current_language is empty but not the user language then we need to assign user language as current language.
             */
             if(empty($user_language) && empty($current_language)){
                $user_language = $system_language;
                $user_language_code = $system_language_code;
                $user_language_alias = $system_language_alias;
                $current_language = $system_language;
                $current_language_code = $system_language_code;
                $current_language_alias = $system_language_alias;
                $cookie_language = $system_language;
                $cookie_language_code = $system_language_code;
                $cookie_language_alias = $system_language_alias;
                /**
                 * Now initialize cookie and global_vars
                 * NOTE: HERE WE NEED TO UPDATE DB AS WELL
                 */ 
                $this->EE->functions->set_cookie('language', $cookie_language, $cookie_expiration);
                $this->EE->functions->set_cookie('language_code', $cookie_language_code, $cookie_expiration);
                $this->EE->functions->set_cookie('language_alias', $cookie_language_alias, $cookie_expiration);
                $this->EE->config->_global_vars['language'] = $current_language;
                $this->EE->config->_global_vars['language_code'] = $current_language_code;
                $this->EE->config->_global_vars['language_alias'] = $current_language_alias;
                
                $data = array('language' => $user_language);

                $this->EE->db->query($this->EE->db->update_string($this->prfx.'members', $data, 'member_id='.$session->userdata['member_id']));
             }
             else if(empty($user_language) && !empty($current_language)){
                $user_language = $current_language;
                $user_language_code = $current_language_code;
                $user_language_alias = $current_language_alias;
                $cookie_language = $current_language;
                $cookie_language_code = $current_language_code;
                $cookie_language_alias = $current_language_alias;
                /**
                 * Now initialize cookie
                 */ 
                $this->EE->functions->set_cookie('language', $cookie_language, $cookie_expiration);
                $this->EE->functions->set_cookie('language_code', $cookie_language_code, $cookie_expiration);
                $this->EE->functions->set_cookie('language_alias', $cookie_language_alias, $cookie_expiration);
                $data = array('language' => $user_language);
                $this->EE->db->query($this->EE->db->update_string($this->prfx.'members', $data, 'member_id='.$session->userdata['member_id']));
             }
             else if(!empty($user_language) && empty($current_language)){
                $current_language = $user_language;
                $current_language_code = $user_language_code;
                $current_language_alias = $user_language_alias;
                $cookie_language = $user_language;
                $cookie_language_code = $user_language_code;
                $cookie_language_alias = $user_language_alias;

                /**
                 * Now initialize cookie
                 * NOTE: HERE WE NEED TO UPDATE DB AS WELL
                 */ 

                $this->EE->functions->set_cookie('language', $cookie_language, $cookie_expiration);
                $this->EE->functions->set_cookie('language_code', $cookie_language_code, $cookie_expiration);
                $this->EE->functions->set_cookie('language_alias', $cookie_language_alias, $cookie_expiration);
                $this->EE->config->_global_vars['language'] = $current_language;
                $this->EE->config->_global_vars['language_code'] = $current_language_code;
                $this->EE->config->_global_vars['language_alias'] = $current_language_alias;
                
                $data = array('language' => $user_language);

                $this->EE->db->query($this->EE->db->update_string($this->prfx.'members', $data, 'member_id='.$session->userdata['member_id']));
             }
             /**
              * Since this is a logged-in user, we will compare current language code to user language. If they are not the same
              * we will set current language as the new user language.
              * 
              * If they match we don't need to do anything so we just return TRUE.
              * 
              * NOTE: HERE WE NEED TO UPDATE DB AS WELL
              */ 
              if($current_language_code != $user_language_code){
                $user_language = $current_language;
                $user_language_code = $current_language_code;
                $user_language_alias = $current_language_alias;
                $cookie_language = $current_language;
                $cookie_language_code = $current_language_code;
                $cookie_language_alias = $current_language_alias;

                /**
                 * Now initialize cookie
                 */ 
                $this->EE->functions->set_cookie('language', $cookie_language, $cookie_expiration);
                $this->EE->functions->set_cookie('language_code', $cookie_language_code, $cookie_expiration);
                $this->EE->functions->set_cookie('language_alias', $cookie_language_alias, $cookie_expiration);

                $data = array('language' => $user_language);

                $this->EE->db->query($this->EE->db->update_string($this->prfx.'members', $data, 'member_id='.$session->userdata['member_id']));
              }
       }
       else{
            /**
             * If this is an anonymous visitor, first thing we need to check is if there is a cookie set.
             * 
             * There is one important condition: If for any reason there is no current language is set;
             * we need to initialize the current language with the language as stated in the default mode.
             */

             if(empty($current_language)){
                switch($default_mode){
                    case 'browser':
                        if(isset($_SERVER['HTTP_ACCEPT_LANGUAGE'])){
                            $temp_language_code = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
                        }
                        else if(isset($system_language)){
                            $temp_language_code = $system_language_code;
                        }
                        else{
                            $temp_language_code = 'en';
                        }
                        break;
                    case 'cookie':
                        /**
                         * if a cookie already set get the cookie set language code otherwise get the system language code.
                         */ 
                        if(isset($cookie_language_code) && !empty($cookie_language_code)){
                            $temp_language_code = $cookie_language_code;
                        }
                        else{
                            $temp_language_code = $system_language_code;
                        }
                        break;
                    case 'system':
                        $temp_language_code = $system_language_code;
                        break;
                }
                /**
                 * Now that we have our temporary language code on hand we can check if the language code matches
                 * to one that is listed in our available languages. If it does not match to any listed languages we
                 * need to switch current language back to system default language.
                 */
                 if(isset($languages[$temp_language_code])){
                    $current_language_code = $temp_language_code;
                    $current_language_alias = $language_aliases[$temp_language_code];
                    $current_language = $languages[$temp_language_code];
                    $this->EE->config->_global_vars['language'] = $current_language;
                    $this->EE->config->_global_vars['language_code'] = $current_language_code;  
                    $this->EE->config->_global_vars['language_alias'] = $current_language_alias;  
                }
                else{
                    $current_language_code = $default_language_code;
                    $current_language_alias = $default_language_alias;
                    $current_language = $default_language;
                    $this->EE->config->_global_vars['language'] = $current_language;
                    $this->EE->config->_global_vars['language_code'] = $current_language_code; 
                    $this->EE->config->_global_vars['language_alias'] = $current_language_alias; 
                }
             }

             /**
              * Now; if current_language is not empty. This means that user has switched the language and therefore 
              * we need to update cookie with current language values.
              */ 
             $cookie_language = $current_language;
             $cookie_language_code = $current_language_code;
             $cookie_language_alias = $current_language_alias;

             /**
              * Now initialize cookie
              */ 
             $this->EE->functions->set_cookie('language', $cookie_language, $cookie_expiration);
             $this->EE->functions->set_cookie('language_code', $cookie_language_code, $cookie_expiration);
             $this->EE->functions->set_cookie('language_alias', $cookie_language_alias, $cookie_expiration);
       } 

       /**
        * Now it's time to set {site_url} variable automatically  based on the site's current language
        * and user settings.
        */
       if(!isset($settings['siteurl_mode'])){
            $settings['siteurl_mode'] = 'keep_siteurlcl';
       }

       /**
        * Automatically set the site_url mode to Keep Untouched for a quick fix.
        * 
        * NOTE: Remove site_url_mode related code completly in the next release.
        */ 
       switch($settings['siteurl_mode']){
            case 'keep_siteurlcl':
            case 'none':
            case 'append_pure':
            default:
                $this->EE->config->_global_vars['site_url_wlc'] = $this->EE->config->item('site_url').$this->EE->config->_global_vars['language_code'].'/';
                break;
       }

       /**
        * register all text to global template variables
        */

       $file_path = PATH_THEMES.'third_party'.$this->dd.'bbr_multilanguagesupport'.$this->dd.'language'.$this->dd
                         .$this->EE->config->_global_vars['language'].$this->dd.'lang.bbr_mysite.php';

       if(!isset($settings['store_engine'])){
            $settings['store_engine'] = 'file';
       }
       if($settings['store_engine'] == 'db'){
            if(isset($settings['texts'])){
                $decoded_texts = unserialize(base64_decode($settings['texts']));
                foreach($decoded_texts as $texts){
                    if(isset($texts[$this->EE->config->_global_vars['language']])){
                        $this->EE->config->_global_vars['bbr-mls-'.$texts['key']] = htmlspecialchars_decode($texts[$this->EE->config->_global_vars['language']], ENT_NOQUOTES);               
                    }
                    else{
                        $this->EE->config->_global_vars['bbr-mls-'.$texts['key']] = '';
                    }
                }
            }
       }
       else{
           if(file_exists($file_path)){
                include($file_path);
                foreach($lang_bbr as $key => $value){
                    $this->EE->config->_global_vars['bbr-mls-'.$key] = htmlspecialchars_decode($value, ENT_NOQUOTES);
                }              
           }
       }
       return TRUE;
    }

    /**
	 * settings()
 	 *
     * @since       1.0.1
     * @date        22.10.2010
     * @author      Can Berkol
     * 
     * @version     2.0.0
     * 
     * Enables CP settings.
	 */

    public function settings_form(){
        /**
         * Retrieve existing settings if there is any.
         */

        $settings = $this->retrieve_settings();
        if(!isset($settings['siteurl_mode'])){
            $settings['siteurl_mode'] = 'append_pure';
        }
        if(!isset($settings['store_engine'])){
            $settings['store_engine'] = 'db';
        }
        /**
         * Read languages
         */ 
        $txt_contents = array();
        if($settings['store_engine'] == 'file'){
            $lang_file = 'lang.bbr_mysite.php';
            $lang_path = PATH_THEMES.'third_party'.$this->dd.'bbr_multilanguagesupport'.$this->dd.'language'.$this->dd;                         
            foreach($settings['available_lang'] as $language){
                $language = strtolower($language);
                if(file_exists($lang_path.$language.$this->dd.$lang_file)){
                    include($lang_path.$language.$this->dd.$lang_file);
                    foreach($lang_bbr as $key => $value){
                        $txt_contents[$key][strtolower($language)] = $value;
                    }
                }
                else{
                    foreach($settings['available_lang'] as $language){
                        $txt_contents[''][strtolower($language)] = '';
                    }
                }
            }
        }
        else{
            if(isset($settings['texts'])){
                $decoded_text = unserialize(base64_decode($settings['texts']));
                foreach($decoded_text as $texts){
                     foreach($settings['available_lang'] as $language){
                        $language = strtolower($language);
                        if(isset($texts[$language])){
                            $txt_contents[$texts['key']][$language] = $texts[$language];  
                        }
                        else{
                            $txt_contents[$texts['key']][$language] = '';  
                        }               
                     }
                }
            }
            else{
                foreach($settings['available_lang'] as $language){
                     $txt_contents[''][strtolower($language)] = '';
                }
            }
        }
        /**
         * Get a list of member groups
         */ 
        $member_groups = $this->list_member_groups($this->site_id);
        /**
         *  Prepare text that will be used in view.
         */ 
        $ext_data['txt'] = array(
                     'button_add'       => $this->EE->lang->line('btn-add'),
                     'button_add_row'   => $this->EE->lang->line('btn-add-row'),
                     'button_delete'    => $this->EE->lang->line('btn-delete'),
                     'button_save'      => $this->EE->lang->line('btn-save'),
                     'error-fill-all'   => $this->EE->lang->line('error-fill-all'),
                     'label_append'     => $this->EE->lang->line('lbl-r-append'),
                     'label_keep'       => $this->EE->lang->line('lbl-r-keep'),
                     'label_none'       => $this->EE->lang->line('lbl-r-none'),
                     'label_defaultlanguage' => $this->EE->lang->line('lbl-def-lang'),
                     'label_defaultlanguagemode' => $this->EE->lang->line('lbl-def-lang-mode'),
                     'label_definelanguages' => $this->EE->lang->line('lbl-t-definelanguages'),
                     'label_engine_db'  => $this->EE->lang->line('lbl-r-engine-db'),
                     'label_engine_file'=> $this->EE->lang->line('lbl-r-engine-file'),
                     'label_engines_available'  => $this->EE->lang->line('lbl-t-engines-available'),
                     'label_browser'    => $this->EE->lang->line('lbl-r-browser'),
                     'label_cookie'     => $this->EE->lang->line('lbl-r-cookie'),
                     'label_key'     => $this->EE->lang->line('lbl-t-key'),
                     'label_siteurlmode'=> $this->EE->lang->line('lbl-t-siteurlmode'),
                     'label_system'    => $this->EE->lang->line('lbl-r-system'),
                     'label_language'   => $this->EE->lang->line('lbl-t-language'),
                     'label_languagealias'   => $this->EE->lang->line('lbl-t-language_alias'),
                     'label_languagecode' => $this->EE->lang->line('lbl-t-language_code'),
                     'label_languagesavailable' => $this->EE->lang->line('lbl-t-languages-a'),
                     'label_visible_settings'   => $this->EE->lang->line('lbl-ms-visible'),
                     'label_visible_translations'   => $this->EE->lang->line('lbl-mt-visible'),
                     'info_engines_available' => $this->EE->lang->line('inf-t-engines-available'),
                     'info_language'   => $this->EE->lang->line('inf-def-lang'),
                     'info_languagemode'   => $this->EE->lang->line('inf-def-lang-mode'),
                     'info_languagecode'   => $this->EE->lang->line('inf-t-language_code'),
                     'info_keys'     => $this->EE->lang->line('inf-t-keys'),
                     'info_siteurl'     => $this->EE->lang->line('inf-t-siteurl'),
                     'info_visible_settings' => $this->EE->lang->line('inf-ms-visible'),
                     'info_visible_translations' => $this->EE->lang->line('inf-mt-visible'),
                     'hdn_options'   => $this->EE->lang->line('hdn-options'),
                     'hdn_settings'   => $this->EE->lang->line('hdn-settings'),
                     'msg_check_all'  => $this->EE->lang->line('msg-check-all'),
                     'msg_selected'   => $this->EE->lang->line('msg-selected'),
                     'msg_selected_none' => $this->EE->lang->line('msg-selected-none'),
                     'msg_uncheck_all'=> $this->EE->lang->line('msg-uncheck-all'),
        );

        $ext_data['available_lang'] = $settings['available_lang'];
        $ext_data['txt_contents'] = $txt_contents;
        $ext_data['settings'] = $settings;
        $ext_data['member_groups'] = $member_groups;
        $ext_data['user_group'] = $this->EE->session->userdata['group_id'];
        return $this->EE->load->view('settings', $ext_data, TRUE);
    }

    /**
	 * read_file()
 	 *
     * @since       2.0.0
     * @date        22.10.2010
     * @author      Can Berkol
     * 
     * Reads file contents into an array
     * 
     * @return      string
	 */
    private function read_file($path){
        $file = array();
        $file = file($path);
        
        return $file;
    }
    /**
	 * get_root_path()
 	 *
     * @since       1.1.3
     * @date        23.09.2010
     * @author      Can Berkol
     * 
     * Reads the root path of EE's installation
     * 
     * @return      string
	 */

    private function get_root_path($fcfile = 'index.php', $fcpath = FCPATH){
        $matches = '';
        $fcparts = explode($this->dd, $fcpath);
        $fcparts_lo = count($fcparts) - 1;
        /**
         * Remove last item if it is empty
         */ 
        if($fcparts[$fcparts_lo] == ''){
            unset($fcparts[$fcparts_lo]);
        }

        $fcparts_lo = count($fcparts) - 1;

        /**
         * Remove sysdir 
         * 
         * Note that we need additional checks for masked cp configuration...
         */
        if(defined('MASKED_CP') && MASKED_CP){
            $doc_root = $_SERVER['DOCUMENT_ROOT'];         
            if(preg_match_all('/\//', $doc_root, $matches) > 0){
                $doc_root = str_replace('/', DIRECTORY_SEPARATOR, $doc_root);
            }
            /** 
             * Updated: 29.06.2012
             * 
             * @since 2.2.1
             * @version 2.2.2
             * Fix for access through cp url
             * 
            */      
            $cp_file = str_replace($this->EE->config->config['site_url'], '', $this->EE->config->config['cp_url']);
            if(strpos($_SERVER['REQUEST_URI'], $cp_file) >= 0){
                $rootpath = FCPATH;
            }
            else{
                if(is_numeric(strpos($fcpath, SYSDIR))){
                    $fcpath = rtrim(str_replace(SYSDIR, '', $fcpath), $this->dd);
                }
                if(is_numeric(strpos($doc_root, $fcpath))){
                    $rootpath = $_SERVER['DOCUMENT_ROOT'];
                }
                else if(is_numeric(strpos($fcpath, $doc_root))){
                    $rootpath = $fcpath;
                }                                 
                else{
                    echo 'BBRMLSx0001 :: There is an unknown error occured while fetching the path to your document root.';
                    exit;
                }
            }                   
        }
        else{
            $this->sysdir = $fcparts[$fcparts_lo];
            unset($fcparts[$fcparts_lo]);
            $rootpath = '';
            foreach($fcparts as $part){
                $rootpath .= $part.$this->dd;
            }
        }  

        if(substr($rootpath, -1) != $this->dd){
            $rootpath = $rootpath.$this->dd;
        }
        return $rootpath;
    }
    /**
	 * is_cp_masked()
 	 *
     * @since       1.1.3
     * @date        23.09.2010
     * @author      Can Berkol
     * 
     * Checks if CP is masked.
     * 
     * @return      bool        true|false
	 */
    private function is_cp_masked(){
         if(defined('MASKED_CP') && MASKED_CP){
            return TRUE;
         }
         else{
            return FALSE;
         }
    }
    /**
	 * save_settings()
 	 *
     * @since       1.0.2
     * @date        19.04.2011
     * @author      Can Berkol
     * @version     2.1.6
     * 
     * Saves extension settings into database.
     * 
     * @return      bool        true|false
	 */
    public function save_settings(){
        $current_settings = $this->retrieve_settings();
        $fcpath = FCPATH;
        $fcfile = 'index.php';
        $rootpath = $this->get_root_path($fcfile);      
        $fullpath = $rootpath.$fcfile;
        /**
         * Control if this file is called by the correct form.
         */
        if($_POST['file'] != 'bbr_multilanguagesupport'){
            return FALSE;
        }
        if(isset($_POST['to_delete']) && $_POST['to_delete'] != ''){
            $to_delete = $_POST['to_delete'];
            /**
             * First we need to delete previous language folders if there exists any.
             */ 

            foreach($to_delete as $folder){
                if($folder != '' && file_exists($rootpath.$folder.$this->dd)){
                    $this->rmdir_recursive($rootpath.$folder.$this->dd);
                }
            } 
        }
        $hide_settings_from = '';
        if(isset($_POST['multiselect_bbr_mls_settings_visibility'])){
            $hide_settings_from = implode(',', $_POST['multiselect_bbr_mls_settings_visibility']);
        }
        $hide_translations_from = '';
        if(isset($_POST['multiselect_bbr_mls_translations_visibility'])){
            $hide_translations_from = implode(',', $_POST['multiselect_bbr_mls_translations_visibility']);
        }
        /**
         *  We need to clean up unnecessary POST keys/value pairs.
         */
        unset($_POST['file'], $_POST['submit'], $_POST['to_delete'], $_POST['submit_bottom'],
              $_POST['multiselect_bbr_mls_settings_visibility'], $_POST['multiselect_bbr_mls_translations_visibility']);
        $settings = array();
        if(!isset($current_settings['store_engine'])){
            $current_settings['store_engine'] = 'db';
        }
        unset($current_settings['submit_bottom']);
        /**
         *  Serialize data to store it in database.
         */ 
        foreach($_POST as $setting => $value){
            if($setting == 'default_language' && empty($value)){
                $value = 'english';
            }
            if($setting == 'available_lang' && $value[0] == ''){
                $value[0] = 'english';
            }
            if($setting == 'available_lang_code' && $value[0] == ''){
                $value[0] = 'en';
            }
            if($setting == 'available_lang_alias' && $value[0] == ''){
                $value[0] = 'English';
            }
            if($setting == 'available_lang'){
                $count = 0;
                foreach($value as $lang){
                    if(empty($lang)){
                        unset($value[$count]);
                    }
                    $count++;
                }
            }
            if($setting == 'available_lang_code'){
                $count = 0;
                foreach($value as $code){
                    if(empty($code)){
                        unset($value[$count]);
                    }
                    $count++;
                }
            }
            $settings[$setting] = $value;
        }
        if(!isset($settings['store_engine'])){
            $settings['store_engine'] = 'db';
        }
        if(isset($settings['siteurl_mode']) && $settings['siteurl_mode'] != 'keep_siteurlcl'){
            $settings['siteurl_mode'] = 'keep_siteurlcl';
        }
        else{
            $settings['siteurl_mode'] = 'keep_siteurlcl';
        }

        $settings['hide_settings'] = $hide_settings_from;
        $settings['hide_translations'] = $hide_translations_from;
        if(serialize($settings) !== serialize($current_settings)){
            $to_delete = (array_diff($current_settings['available_lang_code'], $settings['available_lang_code']));
            /**
             * Now we need to delete old folders if there are any language code changes.
             */ 
            foreach($to_delete as $folder){
                if($folder != '' && file_exists($rootpath.$folder.$this->dd)){
                    $this->rmdir_recursive($rootpath.$folder.$this->dd);
                }
            } 
        }
        /**
         * Update database entry
         */ 
        if(isset($settings['texts'])){
            $settings['texts'] = base64_encode(serialize($settings['texts']));
        }
        $this->EE->db->where('class', get_class($this));
		$this->EE->db->update($this->prfx.'extensions', array('settings' => serialize($settings)));

        /**
         * Here we automatize the creation of multi-lingual paths / folders.
         * 
         * 1. We read the original bootstrap file namley the root index.php.
         */ 

        $bs_file = $this->read_file($fullpath);
        $count = 0;
        $line_number = 0;
        $match_found = FALSE;
        $first = TRUE;
        $sysdir_set = FALSE;
        $is_cp_masked = $this->is_cp_masked();
        $is_absolute_path = FALSE;
        foreach($bs_file as $line){
            $tmp_line = '';
            if(preg_match('/\$system_path/', $line) == 1 && $first){
                $tmp_line = $line;
                $tmp_line = str_replace('$system_path', '', $tmp_line);
                $tmp_line = str_replace('=', '', $tmp_line);
                $tmp_line = str_replace(';', '', $tmp_line);
                $tmp_line = trim($tmp_line);
                $tmp_line = trim($tmp_line, '"');
                $tmp_line = trim($tmp_line, "'");
                $this->sysdir = $tmp_line;
                $first = FALSE;;

                if(substr($this->sysdir, 0, 1) != '.'){
                    $is_absolute_path = TRUE;
                }
            }

            if($is_cp_masked && !$sysdir_set && !$first){
                $tmp_sys = str_replace('.', '\\.', $this->sysdir);
                $tmp_sys = str_replace('/', '\\/', $tmp_sys);
                $str_to_match = '/\$system_path = \\\''.$tmp_sys.'\\\'\;/';
                $sysdir_set = TRUE;       
                if(preg_match($str_to_match, $line) == 1){
                    $match_found = TRUE;
                    break;
                }
            }
            else if(!$is_cp_masked && !$first){
                $tmp_sys = str_replace('.', '\\.', $this->sysdir);
                $tmp_sys = str_replace('/', '\\/', $tmp_sys);
                $str_to_match = '/\$system_path = \\\''.$tmp_sys.'\\\'\;/';

                if(preg_match($str_to_match, $line) == 1){
                    $match_found = TRUE;
                    break;
                }
            }
            $count++;
        }
        if($match_found){
            if(!$is_absolute_path){
                if($is_cp_masked){
                    $bs_file[$count] = '	$system_path = \'../'.$this->sysdir.'\';'.PHP_EOL;
                }
                else{
                    $bs_file[$count] = '	$system_path = \'.'.$this->sysdir.'\';'.PHP_EOL;
                }
            }
            else{
                $bs_file[$count] = '	$system_path = \''.$this->sysdir.'\';'.PHP_EOL;
            }
        }
        else{
            $bs_file[$count] = PHP_EOL
                                .'/* Biber Ltd. :: LOG :: '
                                .$this->sysdir
                                .' is not found in original index.php located in root folder. '
                                .PHP_EOL
                                .' Your index PHP has been modified manually or by another addon, and the global vars section is unable to be modified. */'
                                .PHP_EOL;
        }
        /**
         * Make languages and language codes easier to handle
        */
        $available_languages = $settings['available_lang'];
        $available_language_codes = $settings['available_lang_code'];
        $available_language_aliases = $settings['available_lang_alias'];
        $default_mode = $settings['default_language_mode'];
        $count = 0;
        $languages = array();
        $language_aliases = array();

       /**
         * Create language directories & files
         */ 
        $texts = array();
        if(isset($settings['texts'])){
            $decoded_text = unserialize(base64_decode($settings['texts']));
            $texts = $decoded_text;
        }
        /**
         * Create translation files only if storage engine is set to file.
         */ 
        if($settings['store_engine'] == 'file'){
            $decoded_text = unserialize(base64_decode($settings['texts']));
            foreach($available_languages as $language){
                $this->create_dir(strtolower($language));
                $this->create_file(strtolower($language), $decoded_text);
            }
        }
        foreach($available_language_codes as $language_code){
             $languages[$language_code] = strtolower($available_languages[$count]);
             $language_aliases[$language_code] = $available_language_aliases[$count];
             $count++;
        }
        $line_count = 0;
        $match_found = FALSE;
        foreach($bs_file as $line){
            if(preg_match('/\$assign_to_config\[\'global_vars\'\]/', $line) == 1){
                $match_found = TRUE;
                break;
            }
            $line_count++;
        }

        /**
         * NOTICE: Look for a better way to do this and REDUCE THE NUMBER OF LOOPS!
         */
        /**
         * 3. We create new folders for each of the language codes and we create copies of bootstrap file with certain values 
         * modified.
         */
        foreach($languages as $language_code => $language){
            $tmp_file = $bs_file;
            $merge_file = array();
            $file_size = count($bs_file);
            $start = $line_count;
            /**
             * if there is a write protection in root folder we will flash a contact support message.
             */
            if(!file_exists($rootpath.$language_code.'/')){
                if(!mkdir($rootpath.$language_code.'/')){
                    $this->EE->session->set_flashdata('failure_message', 'Unable to create a dir. Contact support@biberltd.com / 
                    Klasör yaratılamadı destek@biberltd.com ile irtibata geçin.');
                }
                /**
                 * Now if folder exists
                 */
                if(file_exists($rootpath.$language_code.'/')){
                    if($match_found){
                        for($start; $start < $file_size; $start++){
                            $merge_file[] = $tmp_file[$start];
                            unset($tmp_file[$start]);
                        }
                        $tmp_file[] = '	$assign_to_config[\'global_vars\'][\'language\'] = \''.$language.'\';'.PHP_EOL;
                        $tmp_file[] = '	$assign_to_config[\'global_vars\'][\'language_code\'] = \''.$language_code.'\';'.PHP_EOL;
                        $tmp_file[] = '	$assign_to_config[\'global_vars\'][\'language_alias\'] = \''.$language_aliases[$language_code].'\';'.PHP_EOL;
                    }
                    else{
                        for($start; $start < $file_size; $start++){
                            $merge_file[] = $tmp_file[$start];
                            unset($tmp_file[$start]);
                        }
                        $tmp_file[] = PHP_EOL
                                .'/* Biber Ltd. :: LOG :: '
                                .' Your index PHP has been modified manually or by another addon, and the global vars section is unable to be modified. */'
                                .PHP_EOL;
                    }
                }
                /**
                 * Now we need to merge the remaining part of the file...
                 */ 
                $final_file = array_merge($tmp_file, $merge_file);
                file_put_contents($rootpath.$language_code.'/index.php', $final_file);
                unset($tmp_file, $merge_file);
            }
            else{
                /**
                 * Now if folder exists
                 */
                if(file_exists($rootpath.$language_code.'/')){
                     for($start; $start < $file_size; $start++){
                        $merge_file[] = $tmp_file[$start];
                        unset($tmp_file[$start]);
                    }
                    $tmp_file[] = '	$assign_to_config[\'global_vars\'][\'language\'] = \''.$language.'\';'.PHP_EOL;
                    $tmp_file[] = '	$assign_to_config[\'global_vars\'][\'language_code\'] = \''.$language_code.'\';'.PHP_EOL;
                    $tmp_file[] = '	$assign_to_config[\'global_vars\'][\'language_alias\'] = \''.$language_aliases[$language_code].'\';'.PHP_EOL;
                }
                /**
                 * Now we need to merge the remaining part of the file...
                 */ 
                $final_file = array_merge($tmp_file, $merge_file);
                file_put_contents($rootpath.$language_code.'/index.php', $final_file);
                unset($tmp_file, $merge_file);
            }
        }
        /**
         * Lastly, redirect back to extension settings page
         */ 
        $this->EE->functions->redirect(
				BASE.AMP.'C=addons_extensions'.
				AMP.'M=extension_settings'.
				AMP.'file=bbr_multilanguagesupport'
			);
		exit;
    }
    /**
	 * retrieve_settings()
 	 *
     * @since       1.0.1
     * @date        11.08.2010
     * @author      Can Berkol
     * @version     1.1.0
     * 
     * Retrieves stored extension settings from database.
     * 
     * @return      array        $settings
	 */
    public function retrieve_settings(){
        /**
         *  Read and unserialize settings from database
         */ 
        $settings = unserialize($this->EE->db->query('SELECT settings 
                                                FROM '.$this->prfx.'extensions 
			                                    WHERE class = "'.get_class($this).'" LIMIT 1')
                                             ->row('settings')
                                ); 
                                
        return $settings;
    }
    /**
	 * rmdir_recursive()
 	 *
     * @since       1.0.2
     * @date        13.07.2010
     * @author      Can Berkol
     * @version     1.0.5
     * 
     * Deletes a folder recursively.
     * 
     * @param       string      $directory      path of directory
     * 
     * @return      bool        true|false
	 */
    public function rmdir_recursive($directory) {
       $fcpath = FCPATH;
       $fcfile = 'index.php';
       $rootpath = $this->get_root_path($fcfile);  
       if($rootpath != $directory){
            if(is_dir($directory)){
             $objects = scandir($directory);
             foreach ($objects as $object) {
                   if ($object != "." && $object != "..") {
                         if (filetype($directory."/".$object) == "dir"){
                            $this->rmdir_recursive($directory."/".$object); 
                         }
                         else{
                            unlink($directory."/".$object);
                         }
                   }
             }
             reset($objects);
             rmdir($directory);

             return TRUE;
            }
       }

       return FALSE;
    } 

    /**
	 * create_dir()
 	 *
     * @since       2.0.0
     * @date        22.10.2010
     * @author      Can Berkol
     * 
     * Creates language directories within the themese folder, if they do not already exist.
     * 
     * @param       string      $directory      name of directory
     * 
     * @return      bool        true|false
	 */
    public function create_dir($directory) {
       $ext_path = PATH_THEMES.'third_party'.$this->dd
                         .'bbr_multilanguagesupport'.$this->dd.'language'.$this->dd;
       if(!is_dir($ext_path)){
            if (!mkdir($ext_path, 755)){
                return FALSE;
            }
       }
       if(!is_dir($ext_path.$directory)){
            if (!mkdir($ext_path.$directory, 755)){
                return FALSE;
            }
       }
       return TRUE;
    }
    /**
	 * create_file()
 	 *
     * @since       2.0.0
     * @date        25.01.2011
     * @author      Can Berkol
     * @version     2.1.3
     * 
     * Creates language files.
     * 
     * @param       string      $directory      name of directory
     * @param       array       $texts          text
     * 
     * @return      bool        true|false
	 */
    public function create_file($directory, $texts = array()){
        $ext_path = PATH_THEMES.'third_party'.$this->dd
                         .'bbr_multilanguagesupport'.$this->dd.'language'.$this->dd;
        if(count($texts) <= 0){
            $lines = array('<?php '.PHP_EOL.PHP_EOL,
                          '$lang_bbr = array();');
        }
        else{
            $lines = array('<?php '.PHP_EOL.PHP_EOL,
                           '$lang_bbr = array('.PHP_EOL);
            foreach($texts as $text){
                if(isset($text[$directory])){
                    $lines[] = "'".$text['key']."' => '".addslashes($text[$directory])."',".PHP_EOL;
                }
            }
            $lines[] = ');';
        }
        file_put_contents($ext_path.$directory.$this->dd.'lang.bbr_mysite.php', $lines);
    }

    /**
	 * copy_recursive()
 	 *
     * @since       2.1.3
     * @date        28.03.2011
     * @author      Can Berkol
     * 
     * Copies files and folders from source to destination path.
     * 
     * @param       string      $source 
     * @param       string      $destination         
     * 
     * @return      bool        true|false
	 */
    private function copy_recursive($source, $destination) { 
        if(is_dir($source)){
            $handle = opendir($source); 
        }
        if(!file_exists($destination)){
            mkdir($destination, 0755);
        }
        while($file = readdir($handle)){ 
            if($file!='.' && $file!='..'){ 
                if(!is_dir($source.$this->dd.$file)){ 
                    copy ($source.$this->dd.$file, $destination.$this->dd.$file);
                }
                else{
                   $this->copy_recursive($source.$this->dd.$file, $destination.$this->dd.$file);  
                } 
            } 
        } 
        closedir($handle); 
        return TRUE; 
    }

    /**
	 * list_member_groups()
 	 *
     * @since       2.1.8
     * @date        24.06.2011
     * @author      Can Berkol
     * 
     * Lists all available member groups.
     * 
     * @param       integer     $site_id        
     * 
     * @return      bool|array        
	 */
    private function list_member_groups($site_id = 1){
        $query = 'SELECT group_id, group_title FROM '.$this->prfx.'member_groups WHERE site_id = '.$site_id;
        $results = $this->EE->db->query($query);
        $member_groups = $results->result_array();
        if(is_array($member_groups) && $results->num_rows() > 0){
            return $member_groups;
        }
        return FALSE;
    }
    // END
}

/**
 * Change Log:
 * 
 * v 2.2.2
 * - Changed the way MLS stores translations to handle magic_quote settings related issues.
 * - Minor bug fixed.
 * 
 * v 2.2.1
 * - Bug with file paths while accessing control pannel through CP URL instead of system/index.php has been fixed.
 * 
 * v 2.2.0
 * - Minor bug fixes added.
 * 
 * v 2.1.9
 * - Minor bug fixed that caused the MLS settings screen to output an error message.
 *
 * v 2.1.8
 * - site_url mode setting has been finally removed. This will be always set to old "keep untouched" setting.
 * - Setting added to hide settings panel from selected user groups.
 * - Setting added to hide translations panel from selected user groups.
 * - Minor cosmetic changes made.
 * - A minor issue is resolved for those server that do not support $_SERVER['HTTP_ACCEPT_LANGUAGE'].
 * 
 * v 2.1.7
 * - A path related bug is fixed.
 * - Notices due to empty language alias in settings screen has been fixed.
 *  
 *  v 2.1.6
 * - The way the index.php is modified has been changed to provide a broader compatibility. 
 * - Language Alias field to extension settings and language_alias global variable added.
 * - {language_alias} and {default_language_alias} variables added.
 * 
 *  v 2.1.5
 * - A minor bug is fixed. 
 *
 *  v 2.1.4
 * - A bug fixed that prevented auto translation of multiple custom fields in a given exp:channel:entries tag.
 * 
 *  v 2.1.3
 * - A minor bug fixed may cause notice messages to be outputted.
 * - Translation files are moved into themes folder.
 * - The way that index.php is getting modified has been changed.
 *
 * v 2.1.2
 * - A minor bug fixed that issued Warning messages when some other third party add ons have been installed.
 * 
 * v 2.1.1
 * - A bug fixed that prevented custom field based translations from being outputted when no language code is provided in URL.
 * 
 * v 2.1.0
 * - Now CSS and JS files are stored in themes folder.
 * - Now you can forget about creating if/else statements to output the right custom (translation)field for 
 *   your channels. All you need to do is to create custom fields such as content_en, content_tr, etc. and in
 *   your template within the exp:channel:entries tag pair have {bbr-mls:content} and voila! You'll get the
 *   right output for selected language.
 * 
 * v 2.0.8
 * - A bug fixed that prevents translations to be saved in a file when storage engine is selected as File.
 * 
 * v 2.0.7
 * - A bug fixed that prevents correct system directory detection when absolute path is entered. 
 * 
 * v 2.0.6
 * - Minor bug fixes applied to suppress some undesired PHP notices.
 * 
 * v 2.0.5
 * - Bug fixed that caused the software to output a PHP warning when there is no text defined.
 * - Bug fixed that prevented language folder creation in some linux environments.
 * 
 * v 2.0.4
 * - Bug fixed that prevented Site URL Mode to be saved when "None" option is selected.
 * - Bug fixed that prevented the first Save button from functioning when no translations have been entered.
 * 
 * v 2.0.3
 * - Bug that interferes with default language setting mechanism has been fixed..
 *
 * v 2.0.2
 * - Bug which  prevents translations from being ouputted is fixed when DB as storege engine is selecetd.
 * 
 * v 2.0.1
 * - Translation storage engine choices added. Now you can either save translation into a file, or you can keep them only in database.
 * - A bug that prevented strings with quotes to be save is fixed.
 * 
 * v 2.0.0
 * - Now you can define static text content that you want to use in your site right within extension 
 *   control panel.
 * - Defined text is accessible via template variables using {bbr-mls-key} where key is your defined
 *   key for that text.
 * - You can force the actual output of {site_url} to be the actual site url with language code appended to it.
 * 
 * v 1.1.4
 * - Now, fully compatible with Masked System Folder Configuration.
 * 
 * v 1.1.3
 * - Minor bug fixed that prevented cookie mechanism to work properly.
 * 
 * v 1.1.2
 * - Minor bug fixed that prevented routing index.php files to be edited correctly
 * 
 * v 1.1.1
 * - Changed the way the root folder is detected to a more reliable option.
 * - System folder setting is not required anymore and it is removed.
 * 
 * v 1.1.0
 * - Major bug fixed that caused false member entries in database.
 * - Bug fixed that prevented the extension from working if you had custom database table prefixes.
 * - {site_url} template tag now outputs the site url appended with the currently active language code.
 * - {site_url_pure} global template tag added to let you still have the site url with no language code 
 *   appended.
 * - Creates index.php smarter by auto-detecting the lines to be replaced.
 * 
 * v 1.0.7
 * - A new setting added to ease calculations of renamed system folder.
 * - Bug for false path detection is fixed.
 * 
 * v 1.0.6
 * - A workaround has applied to overcome a possible EE bug.
 * 
 * v 1.0.5
 * - Fixed a bug that caused the installation folder to be falsely identified. Now uses internal constants.
 * - Fixed a bug that assumes that system folder is always named as system.
 * 
 * v 1.0.4
 * - A bug fixed that caused a warning to be thrown when user was not logged in and the session user data
 *   had an empty "language" value. 
 * 
 */ 
// END CLASS
?>