<?php
$lang = array(
            'btn-add'               =>      'Yeni Dil Ekle',
            'btn-add-row'           =>      'Yeni Metin Ekle',
            'btn-delete'            =>      'Dili Kaldır',
            'btn-save'              =>      'Kaydet',
            'error-fill-all'        =>      'Görünür tüm alanları doldurmanız gerekmektedir.',
            'lbl-def-lang'          =>      'Varsayılan Dil',
            'lbl-def-lang-mode'     =>      'Varsayılan Dil Seçim Türü',
            'lbl-ms-visible'        =>      'Ayarlar Ekranını Kullanıcılardan Gizle',
            'lbl-mt-visible'        =>      'Çeviriler Ekranını Kullanıcılardan Gizle',
            'lbl-r-append'          =>      'Dil Kodu Ekle',
            'lbl-r-browser'         =>      'Tarayıcıdan',
            'lbl-r-cookie'          =>      'Çerezlerden',
            'lbl-r-engine-db'       =>      'Veri tabanı',
            'lbl-r-engine-file'     =>      'Dosya',
            'lbl-r-keep'            =>      'Dokunmadan Ekle',
            'lbl-r-none'            =>      'Hiçbiri',
            'lbl-r-system'          =>      'Varsayılan Dilden',
            'lbl-t-definelanguages' =>      'Statik Yazı Tanımlama ve Tercüme Ekranı',
            'lbl-t-engines-available'=>     'Tercüme Kayıt Motorunu Seçin',
            'lbl-t-language'        =>      'Dil Adı (İngilizce)',
            'lbl-t-language_alias'  =>      'Dil Adı',
            'lbl-t-language_code'   =>      'Dil Kodu',
            'lbl-t-languages-a'     =>      'Mevcut Diller',
            'lbl-t-key'             =>      'Tanımlayıcı Anahtar',
            'lbl-t-siteurlmode'     =>      '{site_url} Türü',
            'hdn-options'           =>      'Ayarlar',
            'hdn-settings'          =>      'Seçenekler',
            'inf-def-lang'          =>      'Sitenizin varsayılan dilinin, tanımladığınız dillerden hangisi olduğunu belirler.<br />
                                            Bu seçim sitenizi yeni ziyaret edenlerin dilleri dil seçim türlerinden hiçbiri ile 
                                            bağdaştırılamaz ise ziyaretçiye gösterilecek dili belirler.',
            'inf-def-lang-mode'     =>      'Otomatik dil seçiminin hangi kritere göre yapılacağını seçmenize yarar.<br />
                                            Tarayacı, tarayıcı diline göre; çerez çerezlerde kaydedilmiş dile göre; varsayılan ise sistemde 
                                            kaydedilmiş dile göre otomatik olarak dili atar.',
            'inf-ms-visible'        =>      'Ayarlar ekranını seçili kullanıcı gruplarından gizler.',
            'inf-mt-visible'        =>      'Çeviriler ekranını seçili kullanıcı gruplarından gizler.',
            'inf-t-engines-available'=>     'Tercümelerin kaydedilebileceği iki ayrı saklama alanı bulunmaktadır.
                                            <br /><br />
                                            <strong>Veri tabanı</strong><br />
                                            Bu alan veritabanınızda daha fazla yer kaplayacaktır. Ancak dosya erişim hakları ile ilgili problemler yaşıyorsanız bu seçeneği seçmelisiniz. 
                                            <br /><br /><strong>Dosya</strong><br />
                                            Bu seçenek tercümeleri sunucunuzda bir dosyaya yazar. Eğer dosya erişim haklarınızda problem yaşamıyorsanız bu tercihi seçmelisiniz.',
            'inf-t-language_code'   =>      'Dil kodu en fazla 3 harften oluşmalıdır ve İngilizce alfabesinden harfler içermelidir. <br />
                                            Özel karakterler ve imla işaretleri içermeden birleşik tek kelime olarak tanımlanmalıdır.',
            'inf-t-keys'            =>      'İlk sütuna sadece harf ve rakamlardan oluşan tanımlayıcı bir değer girmelisiniz. Buraya Türkçe karakterler ve noktalama işaretleri gibi özel karakterler giremezsiniz. Sadece tire ve alttan çizgi karakterlerine izin verilmektedir. Diğer sütünlara ise anahtara karşılık gelecek metni ve metnin tercümelerini girmelisiniz.',
            'inf-t-siteurl'         =>      'Dil Kodu Ekle seçeneği {site_url} nin sonuna seçili dilin kodunu ekler ve {site_url_pure} adı altında salt URLyi içeren yeni bir değişken yaratır
                                            <br /><br />
                                            Dokunmadan Ekle seçeneği {site_url} değişkenine müdahale etmez ancak {site_url_wlc} adında yeni bir değişken oluşturur. Bu değişken {site_url} değerine seçili dil kodunu ekler. 
                                            <br /><br />
                                            Hiçbiri seçeneğine ne {site_url} değişkenine dokunur ne de yeni bir değişken yaratır. Eğer {site_url} değişkenine dil kodu eklemek isterseniz temalarınızda {site_url}{language_code} yazmanız gerekir.',
            'msg-check-all'         =>      'Hepsini Seç',
            'msg-fail-save'         =>      'Kaydetme işleminde bilinmeyen bir hata meydana geldi.',
            'msg-selected'          =>      'tane seçili',
            'msg-selected-none'     =>      'Hiçbiri Seçili Değil',
            'msg-success-save'      =>      'Ayarlarınız kaydedilmiştir.',
            'msg-uncheck-all'       =>      'Hiçbirini Seçme',
        );
/* End of file lang.bbr_multilanguagesupport.php */
/* Location: ./system/language/turkish/lang.bbr_multilanguagesupport.php */