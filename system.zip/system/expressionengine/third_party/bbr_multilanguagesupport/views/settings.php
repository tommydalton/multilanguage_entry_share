<?php
/**
 * Developed by Biber Ltd. (http://www.biberltd.com)
 * 
 * version:         2.1.8
 * last update:     24 June 2011
 * author:          Can Berkol
 * copyright:       Biber Ltd. (http://biberltd.com)
 * 
 * description:
 * This the view file for settings of the Biber Multi Language Support Extension.
 * 
 */ 
    $this->EE =& get_instance();
    $ext_theme_folder = PATH_THEMES.'third_party/bbr_multilanguagesupport/';
    $ext_theme_url = $this->EE->config->item('theme_folder_url').'third_party/bbr_multilanguagesupport/';
    $this->EE->cp->add_to_head('<script type="text/javascript" src="'.$ext_theme_url.'javascript/jquery.ui_1.8.js"></script>');
    $this->EE->cp->add_to_head('<script type="text/javascript" src="'.$ext_theme_url.'javascript/jquery.multiselect.js"></script>');
    $this->EE->cp->add_to_head('<script type="text/javascript" src="'.$ext_theme_url.'javascript/bbr_multilanguagesupport.js"></script>');
    $this->EE->cp->add_to_head('<link rel="stylesheet" type="text/css" href="'.$ext_theme_url.'css/bbr_multilanguagesupport.css" />');
    $this->EE->cp->add_to_head('<link rel="stylesheet" type="text/css" href="'.$ext_theme_url.'css/jquery.ui.css" />');
    if(!isset($settings['hide_settings'])){
        $settings['hide_settings'] = '';
    }
    if(!isset($settings['hide_translations'])){
        $settings['hide_translations'] = '';
    }
    $hide_settings = explode(',', $settings['hide_settings']);
    $hide_translations = explode(',', $settings['hide_translations']);
    $ext_html = '';
    /**
     * Load extension text
     */
    /**
     * Open Form
     */ 
    $form_open = form_open('C=addons_extensions'.AMP.'M=save_extension_settings', 
                    array('id' => 'bbr_multilanguagesupport'), 
                    array('file' => 'bbr_multilanguagesupport')
                   );
    $error = '<div id="error_container">
                <div id="err_empty">
                    '.$txt['error-fill-all'].'</div></div>';
    
    /**
     * Prepare INNER TABLE
     */ 
    $this->table->set_template($cp_pad_table_template);
    $this->table->set_heading(array(
        array(
            'data'  => $txt['label_language'],
            'style' => 'width:30%;'
        ),
        array(
            'data'  => $txt['label_languagealias'],
            'style' => 'width:30%;'
        ),
        array(
            'data'  => $txt['label_languagecode'],
            'style' => 'width:30%;'
        ),
        array(
            'data'  => '',
            'style' => 'width:10%;'
        ),
    ));
    /**
     *  Prepare row values of settings column
     */
    $inputs = '';
    $count = 0;
    foreach($settings['available_lang'] as $language){
        $tmp_lang_alias = '';
        if(isset($settings['available_lang_alias'][$count])){
            $tmp_lang_alias = $settings['available_lang_alias'][$count];
        }
        $row_languagesetting = '<input type="text" id="language-'.$count.'" name="available_lang[]" value="'.$language.'" />';
        $row_languagealiassetting = '<input type="text" id="language_alias-'.$count.'" name="available_lang_alias[]" value="'.$tmp_lang_alias.'" />';
	    $row_languagecodesetting = '<input type="text" id="language_code-'.$count.'" name="available_lang_code[]" value="'.$settings['available_lang_code'][$count].'" />';
        $row_delete = '<div class="bbr_delete_button_container"><a id="rowdelete-'.$count.'" class="bbr_delete_button"></a></div>';
        $this->table->add_row($row_languagesetting, $row_languagealiassetting, $row_languagecodesetting, $row_delete);
        $count++;
    }
    /**
     * Add Row
     */ 
    $inner_table = $error.$this->table->generate();
    /**
     *  Add "NEW ROW" button
     */ 
    $button_add_container = '<a id="bbr_add_new_lang" class="bbr_add_button">'.$txt['button_add'].'</a>';
    $inner_table .= $button_add_container;
    /**
     * Now clear existing data and get ready for preparations of outer table
     */ 
    $this->table->clear();
    /**
     * Prepare OUTER TABLE
     */ 
    $this->table->set_template($cp_pad_table_template);
    if(in_array($user_group, $hide_settings)){
        $hidden_tpl = table_hidden_panel_tpl();
        $this->table->set_template($hidden_tpl);
    }
    $this->table->set_heading(array(
        array(
            'data'  => $txt['hdn_options'],
            'style' => 'width:50%;'
        ),
        array(
            'data'  => $txt['hdn_settings'],
            'style' => 'width:50%;'
        ),
    ));
    /**
     *  Prepare row values of settings column
     */
    $checked_append = '';
    $checked_keep = '';
    $checked_none = '';
    /** Run a quick check for member groups; if they are not loaded  */
    if(!isset($member_groups) || !is_array($member_groups)){
        $member_groups = array();
    }
    /**
     * site_url mode has been removed as of version 2.1.8
     * 
     * *********************************************
     * Visibility Settings for Settings Screen
     * *********************************************
     */ 
    $options = '';
    foreach($member_groups as $group){
        if($group['group_title'] != 'Super Admins'){
            if(in_array($group['group_id'], $hide_settings)){
                $options .= '<option value="'.$group['group_id'].'" selected="selected">'.$group['group_title'].'</option>';
            }
            else{
                $options .= '<option value="'.$group['group_id'].'">'.$group['group_title'].'</option>';
            }
            
        }
    }
    $row_settingsvisibility =
    '<div class="bbr_visibility_container">'.
        '<select id="bbr_mls_settings_visibility" multiple="multiple">
            '.$options.'
         </select>'.
    '</div>';
    $js_settingsvisibility = '
    <script language="javascript">
    $(document).ready(function(){
        $("#bbr_mls_settings_visibility").multiselect({
            checkAllText: "'.$txt['msg_check_all'].'",
            uncheckAllText: "'.$txt['msg_uncheck_all'].'",
            noneSelectedText: "'.$txt['msg_selected_none'].'",
            selectedText: "# '.$txt['msg_selected'].'"
        });
    });
    </script>
    ';
    /**
     * site_url mode has been removed as of version 2.1.8
     * 
     * *********************************************
     * Visibility Settings for Translation Screen
     * *********************************************
     */ 
    $options = '';
    foreach($member_groups as $group){
        if($group['group_title'] != 'Super Admins'){
            if(in_array($group['group_id'], $hide_translations)){
                $options .= '<option value="'.$group['group_id'].'" selected="selected">'.$group['group_title'].'</option>';
            }
            else{
                $options .= '<option value="'.$group['group_id'].'">'.$group['group_title'].'</option>';
            }
            
        }
    }
    $row_translationsvisibility =
    '<div class="bbr_visibility_container">'.
        '<select id="bbr_mls_translations_visibility" multiple="multiple">
            '.$options.'
         </select>'.
    '</div>';
    $js_translationvisibility = '
    <script language="javascript">
    $(document).ready(function(){
        $("#bbr_mls_translations_visibility").multiselect({
            checkAllText: "'.$txt['msg_check_all'].'",
            uncheckAllText: "'.$txt['msg_uncheck_all'].'",
            noneSelectedText: "'.$txt['msg_selected_none'].'",
            selectedText: "# '.$txt['msg_selected'].'"
        });
    });
    </script>
    ';
    $checked_browser = '';
    $checked_cookie = '';
    $checked_system = '';
    switch($settings['default_language_mode']){
        case 'browser':
            $checked_browser = ' checked="checked"';
            break;
        case 'cookie':
            $checked_cookie = ' checked="checked"';
            break;
        case 'system':
            $checked_system = ' checked="checked"';
            break;
    }
    $row_mode =
    '<div id="bbr_languagemode_container">'.
        '<input type="radio" name="default_language_mode" value="browser" id="browser"'.$checked_browser.' /><label for="browser">'
                            .$txt['label_browser'].'</label>'.
        '<input type="radio" name="default_language_mode" value="cookie" id="cookie"'.$checked_cookie.' /><label for="cookie">'.$txt['label_cookie'].'</label>'.
        '<input type="radio" name="default_language_mode" value="system" id="system" '.$checked_system.' /><label for="system">'.$txt['label_system'].'</label>'.
    '</div>';
    /**
     * Create options from available languages
     */
    $options = '';
    $i = 0;
    foreach($settings['available_lang'] as $language){
        $language_safe = strtolower(str_replace(' ', '_', $language));
        if(isset($settings['available_lang_alias'][$i]) && $settings['available_lang_alias'][$i] != ''){
            $language = $settings['available_lang_alias'][$i];
        }
        if($settings['default_language'] == $language_safe){
            $options .= '<option value="'.$language_safe.'" selected="selected">'.$language.'</option>';
        }
        else{
            $options .= '<option value="'.$language_safe.'">'.$language.'</option>';
        }
        $i++;
    }
    $row_defaultlanguage =
    '<div class="bbr_selectbox_container">
        <select id="default_language" name="default_language">
	       '.$options.'
        </select>
    </div>';
    $checked_db = '';
    $checked_file = '';
    if(!isset($settings['store_engine'])){
        $settings['store_engine'] = 'file';
    }
    switch($settings['store_engine']){
        case 'file':
            $checked_file = ' checked="checked"';
            break;
        case 'db':
        default:
            $checked_db = ' checked="checked"';
            break;
    }
    $row_engine =
    '<div id="bbr_storageengine_container">'.
        '<input type="radio" name="store_engine" value="file" id="store_engine_db"'.$checked_file.' /><label for="store_engine_db">'
                            .$txt['label_engine_file'].'</label>'.
        '<input type="radio" name="store_engine" value="db" id="store_engine_file"'.$checked_db.' /><label for="store_engine_file">'.$txt['label_engine_db'].'</label>'.
    '</div>';
    $row_availablelanguages = $inner_table;	
    $this->table->add_row('<label>'.$txt['label_visible_settings'].'</label>'
                            .'<br /><div class="bbr_small_info">'.$txt['info_visible_settings'].'</div>', $row_settingsvisibility.$js_settingsvisibility);			
    $this->table->add_row('<label>'.$txt['label_visible_translations'].'</label>'
                            .'<br /><div class="bbr_small_info">'.$txt['info_visible_translations'].'</div>', $row_translationsvisibility.$js_translationvisibility);			
    $this->table->add_row('<label>'.$txt['label_defaultlanguagemode'].'</label>'
                            .'<br /><div class="bbr_small_info">'.$txt['info_languagemode'].'</div>', $row_mode);
    $this->table->add_row('<label>'.$txt['label_language'].'</label>'
                            .'<br /><div class="bbr_small_info">'.$txt['info_language'].'</div>', $row_defaultlanguage);
    $this->table->add_row('<label>'.$txt['label_languagesavailable'].'</label>'
                            .'<br /><div class="bbr_small_info">'.$txt['info_languagecode'].'</div>', $row_availablelanguages);
    $this->table->add_row('<label>'.$txt['label_engines_available'].'</label>'
                            .'<br /><div class="bbr_small_info">'.$txt['info_engines_available'].'</div>', $row_engine);

    $outer_table = $this->table->generate();
    $hide_button = '';
    if(in_array($user_group, $hide_settings)){
        $hide_button = ' hidden_button';
    }
    $submit_button = form_submit(array('id' => 'bbr_mls_submit','name' => 'submit', 'value' => $txt['button_save'], 'class' => 'submit'.$hide_button));
    /**
     * Close Form
     */ 
    $form_close = form_close();
    
    /**
     * Here we need a new main table for users to define language variables.
     */
    $language_rows = '';
    $this->table->clear();
    /**
     * Prepare INNER TABLE
     */ 
    $this->table->set_template($cp_pad_table_template);
    $heading_array = array(array('data'  => $txt['label_key'], 'style' => 'width:15%;'));
    $lang_count = count($available_lang);
    if($lang_count > 0){
        $width = 80 / $lang_count;
    }
    else{
        $width = 80;
    }
    $i = 0;
    foreach($available_lang as $lang){
        if(isset($settings['available_lang_alias'][$i]) && $settings['available_lang_alias'][$i] != ''){
            $lang = $settings['available_lang_alias'][$i];
        }
        $heading_array[] = array('data'  => $lang, 'style' => 'width:'.$width.'%;');
        $i++;
    }
    $heading_array[] = array('data'  => '', 'style' => 'width:5%;');
    /**
     * Prepare rows
     */ 
    $count = 0;
    foreach($txt_contents as $key => $langs){
        $str_to_evaluate = '$this->table->add_row(';
        $str_to_evaluate .= "'<input type=\"text\" id=\"lang-key-$count\" name=\"texts[".$count."][key]\" value=\"$key\" />',";
        foreach($langs as $lang => $text){
            $text = htmlspecialchars($text, ENT_QUOTES);
            $str_to_evaluate .= "'<input type=\"text\" id=\"text-$lang-$count\" name=\"texts[".$count."][$lang]\" value=\"$text\" />',";
        }
        $str_to_evaluate .= "'<div class=\"bbr_delete_button_container\"><a id=\"langrowdelete-$count\" class=\"bbr_lang_delete_button\"></a></div>'";
        $str_to_evaluate .= ');';
        $count++;
        eval($str_to_evaluate);
    }
    $this->table->set_heading($heading_array);
    $language_rows = $this->table->generate().'<a id="bbr_add_new_lang_row" class="bbr_add_button">'.$txt['button_add_row'].'</a>';

    $languages_html = '';
    $this->table->clear();
    /**
     * Prepare OUTER TABLE
     */ 
    $this->table->set_template($cp_pad_table_template);
    if(in_array($user_group, $hide_translations)){
        $hidden_tpl = table_hidden_panel_tpl();
        $this->table->set_template($hidden_tpl);
    }
    $this->table->set_heading(array(
        array(
            'data'  => $txt['label_definelanguages'],
            'style' => 'width:100%;'
        ),
    ));
    $this->table->add_row('<br />'.$txt['info_keys'].'<br /><br />'.$language_rows);
    $languages_html = $this->table->generate();
    $hide_button = '';
    if(in_array($user_group, $hide_translations)){
        $hide_button = ' hidden_button';
    }
    $submit_button_bottom = form_submit(array('id' => 'bbr_mls_submit_bottom','name' => 'submit_bottom', 'value' => $txt['button_save'], 'class' => 'submit'.$hide_button));

    $ext_html = $form_open.$outer_table.$submit_button.'<br /><br />'.$languages_html.$submit_button_bottom.$form_close;
    
    echo $ext_html;
    
    function table_hidden_panel_tpl(){
		return  array (
				'table_open'			=> '<table border="0" cellpadding="4" cellspacing="0" style="display:none">',

				'thead_open'			=> '<thead>',
				'thead_close'			=> '</thead>',

				'heading_row_start'		=> '<tr>',
				'heading_row_end'		=> '</tr>',
				'heading_cell_start'	=> '<th>',
				'heading_cell_end'		=> '</th>',

				'tbody_open'			=> '<tbody>',
				'tbody_close'			=> '</tbody>',

				'row_start'				=> '<tr>',
				'row_end'				=> '</tr>',
				'cell_start'			=> '<td>',
				'cell_end'				=> '</td>',

				'row_alt_start'	      	=> '<tr>',
				'row_alt_end'			=> '</tr>',
				'cell_alt_start'		=> '<td>',
				'cell_alt_end'			=> '</td>',

				'table_close'			=> '</table>'
			);
    }
?>