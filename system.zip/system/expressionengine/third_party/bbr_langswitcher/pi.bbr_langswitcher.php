<?php
/**
 * Developed by Biber Ltd. (http://www.biberltd.com)
 *
 * version:         1.0.5
 * last update:     30 May 2011
 * author:          Can Berkol
 * copyright:       Biber Ltd. (http://biberltd.com)
 *
 * description:
 * This plugin can be used with Biber Ltd. Multi Language Support extension only.
 *
 * This plugin eases the process to create a language switching navigation.
 *
 */

if ( ! defined('BASEPATH')) exit('No direct script access allowed');


$plugin_info = array(
  'pi_name'     => 'Biber Language Switcher',
  'pi_version'  => '1.0.4',
  'pi_author'   => 'Biber Ltd.com',
  'pi_author_url'=>'http://www.biberltd.com/wiki/English:bbr_langswitcher/',
  'pi_description'=>'Returns the value of a language array key.',
  'pi_usage' => Bbr_langswitcher::usage()
);

class Bbr_langswitcher {
    public $return_data = '';

    public $show_current = 'no';
    public $show_alias = 'no';
    public $orderby = 'language';
    public $sort = 'asc';
    public $remove_segments = '';

    private $total_languages = 0;
    private $total_visible_languages = 0;
    private $extension = 'Bbr_multilanguagesupport_ext';
    private $prfx;
    /**
     * Constructor
     *
     * @since       1.0.0
     * @date        26.09.2010
     * @author      Can Berkol
     *
     * PHP 5.0 & above
     */
    public function __construct(){
        $this->EE =& get_instance();
        $this->prfx = $this->EE->db->dbprefix;
        /**
         * Read contents of plugin parameters.
         */
        if($this->EE->TMPL->fetch_param('show_current')){
            $this->show_current = $this->EE->TMPL->fetch_param('show_current');
        }
        if($this->EE->TMPL->fetch_param('show_alias')){
            $this->show_alias = $this->EE->TMPL->fetch_param('show_alias');
        }
        if($this->EE->TMPL->fetch_param('remove_segments')){
            $this->remove_segments = $this->EE->TMPL->fetch_param('remove_segments');
        }
        if($this->EE->TMPL->fetch_param('orderby')){
            $this->orderby = $this->EE->TMPL->fetch_param('orderby');
        }
        if($this->EE->TMPL->fetch_param('sort')){
            $sort = strtolower($this->EE->TMPL->fetch_param('sort'));
            switch($sort){
                case 'asc':
                case 'desc':
                    $this->sort = $sort;
                    break;
            }
        }

        $this->return_data = $this->build_switcher();
    }
    function Bbr_langswitcher(){
        $this->__construct();
    }
    /**
     * Destructor
     *
     * @since       1.0.0
     * @date        26.09.2010
     * @author      Can Berkol
     *
     * PHP 5.0 & above
     */
    public function __destructor(){
        foreach($this as $property => $value){
            $this->$property = null;
        }
    }
    /**
     * build_switcher
     *
     * @since       1.0.0
     * @date        26.09.2010
     * @author      Can Berkol
     *
     * Builds the switcher.
     */
    private function build_switcher(){
        /**
         * Grab all segments from URI.
         */
        $segments = $this->EE->uri->segments;
        $segments_to_remove = array();
        /**
         * Remove the user requested segments
         */
        if(!empty($this->remove_segments)){
            $segments_to_remove = explode('|', $this->remove_segments);
        }
        $segments = array_diff($segments, $segments_to_remove);
        $segment_string = '';
        if(is_array($segments) && count($segments) > 0){
            foreach($segments as $segment){
                $segment_string .= $segment.'/';
            }
        }
        /**
         * Currently selected language that the web site is viewed by the user.
         */
        $selected_language = $this->EE->config->_global_vars['language'];
        $selected_language_code = $this->EE->config->_global_vars['language_code'];
        $selected_language_alias = $this->EE->config->_global_vars['language_alias'];
        $current_language[$selected_language_code] = $selected_language;
        $current_alias[$selected_language_code] = $selected_language_alias;
        /**
         * Get the list of all avaialbale languages.
         */
        $languages = $this->list_languages($selected_language_code);
        if(isset($languages[$selected_language_code]['lang'])){
             $current_language[$selected_language_code] = $languages[$selected_language_code]['lang'];
        }
        /**
         * Now read plugin-template data
         */
        $tag_data = $this->EE->TMPL->tagdata;
        /**
         * Get contents of {lang_loop}
         *
         * This will be then used to loop to create the list of languages.
         */
        $match = array();
        preg_match("/".LD."lang_loop".RD."(.*?)".LD.'\/lang_loop'.RD."/s", $tag_data, $match);
        $matched_content = $match[1];
        /**
         * Get contents of switch variable in {lang_loop}
         */
        $switch_match = array();
        $alternate = array();
        preg_match("/".LD."switch\s*\=\s*\"(.*?)\"".RD."/s", $matched_content, $switch_match);
        if(count($switch_match) > 0){
            $alternate = explode('|', $switch_match[1]);
        }
        $loop_content = '';
        $replaced_content = '';
        $count = 1;
        $alternate_size = count($alternate);
        $alternate_count = 0;
        foreach($languages as $code => $details){
            $replaced_content = str_replace(LD.'bbr_lang'.RD, $details['lang'], $matched_content);
            $replaced_content = str_replace(LD.'bbr_lang_alias'.RD, $details['alias'], $replaced_content);
            $replaced_content = str_replace(LD.'bbr_lang_code'.RD, $code, $replaced_content);
            $replaced_content = str_replace(LD.'bbr_count'.RD, $count, $replaced_content);
            $replaced_content = str_replace(LD.'bbr_total'.RD, $this->total_visible_languages, $replaced_content);
            /**
             * Replace the {switch} content
             */
            if($alternate_size > 0 && $alternate_count < $alternate_size){
                $replaced_content = preg_replace("/".LD."switch\s*\=\s*\"(.*?)\"".RD."/s", $alternate[$alternate_count], $replaced_content);
                $alternate_count++;
            }
            else if ($alternate_size > 0){
                $alternate_count = 0;
                $replaced_content = preg_replace("/".LD."switch\s*\=\s*\"(.*?)\"".RD."/s", $alternate[$alternate_count], $replaced_content);
                $alternate_count++;
            }
            $loop_content .= $replaced_content;
            $count++;

        }
        $tag_data = preg_replace("/".LD."lang_loop".RD."(.*?)".LD.'\/lang_loop'.RD."/s", $loop_content, $tag_data);
        $tag_data = str_replace(LD.'current_language'.RD, $current_language[$selected_language_code], $tag_data);
        $tag_data = str_replace(LD.'current_language_code'.RD, $selected_language_code, $tag_data);
        $tag_data = str_replace(LD.'current_language_alias'.RD, $selected_language_alias, $tag_data);
        $tag_data = str_replace(LD.'bbr_segments'.RD, $segment_string, $tag_data);
        $tag_data = str_replace(LD.'total_languages'.RD, $this->total_languages, $tag_data);
        return $tag_data;
    }
    /**
     * list_languages
     *
     * @since       1.0.0
     * @date        26.09.2010
     * @author      Can Berkol
     *
     * @version     1.0.2
     *
     * Filters, sorts and lists languages based on plugin parameters.
     */
    private function list_languages($selected_language_code){
        $query = 'SELECT settings FROM '
                    .$this->prfx.'extensions WHERE class = "'.$this->extension.'" LIMIT 1';
        $result = $this->EE->db->query($query);
        $extension_settings = unserialize($result->row('settings'));
        $count = 0;
        $languages = array();
        $tmp_languages = array();
        $lang_names = array();
        $lang_aliases = array();
        foreach($extension_settings['available_lang_code'] as $code){
            $tmp_languages[$code]['lang'] = $extension_settings['available_lang'][$count];
            $tmp_languages[$code]['alias'] = $extension_settings['available_lang_alias'][$count];
            $lang_names[$code] = $extension_settings['available_lang'][$count];
            $lang_aliases[$code] = $extension_settings['available_lang_alias'][$count];
            $count++;
        }
        /**
         * Set the absolute total number of languages.
         */
        $this->total_languages = count($lang_names);
        if($this->show_current == 'no'){
            unset($lang_names[$selected_language_code], $lang_aliases[$selected_language_code]);
            unset($tmp_languages[$selected_language_code]);
        }
        /**
         * Set the total number of languages that are shown.
         */
        $this->total_visible_languages = count($lang_names);
        if(!empty($this->orderby)){
            switch($this->orderby){
                case 'language':
                    switch($this->sort){
                        case 'asc':
                            asort($lang_names);
                            foreach($lang_names as $key => $value){
                                $languages[$key]['lang'] = $lang_names[$key];
                                $languages[$key]['alias'] = $lang_aliases[$key];
                            }
                            unset($tmp_languages);
                            break 2;
                        case 'desc':
                            arsort($lang_names);
                            foreach($lang_names as $key => $value){
                                $languages[$key]['lang'] = $lang_names[$key];
                                $languages[$key]['alias'] = $lang_aliases[$key];
                            }
                            unset($tmp_languages);
                            break 2;
                    }
                case 'language_alias':
                    switch($this->sort){
                        case 'asc':
                            asort($lang_aliases);
                            foreach($lang_aliases as $key => $value){
                                $languages[$key]['lang'] = $lang_names[$key];
                                $languages[$key]['alias'] = $lang_aliases[$key];
                            }
                            unset($tmp_languages);
                            break 2;
                        case 'desc':
                            arsort($lang_aliases);
                            foreach($lang_aliases as $key => $value){
                                $languages[$key]['lang'] = $lang_names[$key];
                                $languages[$key]['alias'] = $lang_aliases[$key];
                            }
                            unset($tmp_languages);
                            break 2;
                    }
                case 'language_code':
                    switch($this->sort){
                        case 'asc':
                            ksort($tmp_languages);
                            $languages = $tmp_languages;
                            unset($tmp_languages);
                            break 2;
                        case 'desc':
                            krsort($tmp_languages);
                            $languages = $tmp_languages;
                            unset($tmp_languages);
                            break 2;
                    }
            }
        }
        return $languages;
    }
    /**
     * usage
     *
     * @since       1.0.0
     * @date        16.07.2010
     * @author      Can Berkol
     *
     * Shows usage information in plugin control panel.
     */
    public static function usage(){
      ob_start(); 
      ?>
    This plugin is produced to work with Biber Ltd. Multi Language Support extension only.

    Using this plugin you can generate a language switcher for your site visitors easily.

    The plugin accepts four parameters:

    - show_current      optional. yes|no Default value is no.

                        If set to yes it also shows user's current selected language
                        (the one that the site is visible at the moment) in the language list/loop.

    - remove_segments   optional. Accepts any string. Default value is an empty string. If you want
                        multiple items to be removed, you need to separate each item with | pipe
                        character.

                        This parameter helps you to remove unwanted segments from {bbr_segments} variable.

    - orderby           optional. language|language_code Default value is an empty string.

                        Defines the sort criteria for the language list. If left empty; the list will be
                        shown in the order of your Multi Language Extension's setting screen.

                        language : Is used to sort the list by the full language name.
                        language_code : Is used to sort the list by the language code.

    - sort              optional. asc|desc Default value is asc.

                        Defines the sort order.

    The plugin provides four plugin-wide single variables:

    - {current_language}        Outputs the full language name of the currently selected language.

    - {current_language_alias}  Outputs the full language alias of the currently selected language.

    - {current_language_code}   Outputs the language code of the currently selected language.

    - {bbr_segments}            Outputs all (or filtered) list of URI segments as appear in your URL.
                                (i.e. mytemplate_name/contact/)

    - {total_languages}         Outputs the total number of languages available in your

    The plugin provides one plugin-wide variable pair:

    - {lang_loop}{/lang_loop}   This loop is used to output the list of languages.

    The {lang_loop} provides five single variables:

    - {switch = "even|odd"}     This variable is used to alternate values at each iteration of the list.
                                Each item must be separated with | pipe character.

    - {bbr_count}               This variable is an incremental count and shows at which iteration the
                                loop currently is.


    - {bbr_lang}                This variable outputs the full language name for each iteration.

    - {bbr_lang_alias}         This variable outputs the full language alias for each iteration.

    - {bbr_lang_code}           This variable outputs the language code for each iteration.

    - {bbr_total}               This variable outputs the total number of languages to be shown in this loop.

    EXAMPLE CODE:

    {exp:bbr_langswitcher show_current="no" orderby="language_code" sort="asc" remove_segments="template_group_name"}
    <span>Your current language is: {current_language} - {current_language_code}</span>
    <ul>
    	{lang_loop}
    		{if "{bbr_count}" == "1"}
    			<li class='first {switch = "even|odd"}'><a href="{site_url_pure}{bbr_lang_code}/{bbr_segments}">{bbr_lang_alias}</a></li>
    		{if:elseif "{bbr_count}" == "{bbr_total}"}
    			<li class='last {switch = "even|odd"}'><a href="{site_url_pure}{bbr_lang_code}/{bbr_segments}">{bbr_lang_alias}</a></li>
    		{if:else}
    			<li class='{switch = "even|odd"}'><a href="{site_url_pure}{bbr_lang_code}/{bbr_segments}">{bbr_lang_alias}</a></li>
    		{/if}
    	{/lang_loop}
    </ul>
    {/exp:bbr_langswitcher}

    Assuming that you have defined three languages Turkish (tr), German (de), French (fr), and English (en);
    and assuming that you are currently visiting the site in Turkish; the output of this code will be.

    <span>Your current language is: Turkish - tr</span>
    <ul>
        <li class='first even'><a href="http://yoursite.com/de/">German</a></li>
        <li class='odd'><a href="http://yoursite.com/en/">English</a></li>
        <li class='last even'><a href="http://yoursite.com/fr/">French</a></li>
    </ul>
      <?php
      $buffer = ob_get_contents();

      ob_end_clean();

      return $buffer;
      }
      // END
}
/**
 * Change Log:
 *
 * v 1.0.5
 *
 * - A bug fixed that caused {total_languages} output 0.
 *
 * v 1.0.4
 *
 * - A bug fixed that caused show_current="no" to be ignored when languages are ordered by code.
 *
 * v 1.0.3
 *
 * - A minor bug is fixed.
 *
 * v 1.0.2
 *
 * - bbr_alias variable added to lang_loop.
 * - current_language_alias variable added.
 *
 * v 1.0.1
 *
 * - current_language and current_language_code were outputting each other's values. This has been fixed.
 *
 */
/* End of file pi.bbr_gettext.php */
/* Location: ./system/expressionengine/third_party/bbr_multilanguagesupport/pi.bbr_gettext.php */
?>
