<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

// @version 1.03

define('PORTAL_VERSION',       '1.03');
define('PORTAL_NAME',          'Portal');
define('PORTAL_CLASS',         'Portal'); // must match module class name
define('PORTAL_DESCRIPTION',   'Portal - Magically move strings from one place to another');
define('PORTAL_DOCSURL',       'http://metasushi.com');
define('PORTAL_DEBUG',         TRUE);
