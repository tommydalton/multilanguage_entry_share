<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @package Portal
 * @author Isaac Raway (MetaSushi, LLC) <airways@mm.st>
 *
 * Copyright (c)2015. Isaac Raway and MetaSushi, LLC.
 * All rights reserved.
 *
 * This source is commercial software. Use of this software requires a
 * site license for each domain it is used on. Use of this software or any
 * of its source code without express written permission in the form of
 * a purchased commercial or other license is prohibited.
 *
 * THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
 * KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
 * PARTICULAR PURPOSE.
 *
 * As part of the license agreement for this software, all modifications
 * to this source must be submitted to the original author for review and
 * possible inclusion in future releases. No compensation will be provided
 * for patches, although where possible we will attribute each contribution
 * in file revision notes. Submitting such modifications constitutes
 * assignment of copyright to the original author (Isaac Raway and
 * MetaSushi, LLC) for such modifications. If you do not wish to assign
 * copyright to the original author, your license to  use and modify this
 * source is null and void. Use of this software constitutes your agreement
 * to this clause.
 *
 **/

require_once 'config.php';

$plugin_info = array(
    'pi_name'        => PORTAL_NAME,
    'pi_version'     => PORTAL_VERSION,
    'pi_author'      => 'Isaac Raway',
    'pi_author_url'  => PORTAL_DOCSURL,
    'pi_description' => PORTAL_DESCRIPTION,
    'pi_usage'       => '

Exmple code:

{exp:portal}
    {portal:move_it}
        Move this around!
    {/portal:move_it}
    {portal:move_it:append}
        Take this with you!
    {/portal:move_it:append}

    <div class="wrapper">
        {move_it}
    </div>
{/exp:portal}


This will spit out something like:

<div class="wrapper">
    Move this around!
    Take this with you!
</div>


    '
  );

class Portal
{
    function __construct()
    {
        $this->EE =& get_instance();

        $tagdata = $this->EE->TMPL->tagdata;
        $this->EE->TMPL->log_item('Portal: '.$tagdata);
        
        $variables = array();
        $pattern = '#'.LD.'portal(.*)'.RD.'(.*)'.LD.'/portal.*'.RD.'#sU';
        $this->EE->TMPL->log_item('Portal: Pattern = '.$pattern);
        if($count = preg_match_all($pattern, $tagdata, $matches)) {
            foreach($matches[0] as $i => $match) {
                @list($var, $action) = explode(':', trim($matches[1][$i], ':'));
                $value = trim($matches[2][$i]);
                switch($action) {
                    case '':
                        $variables[$var] = $value;
                        break;
                    case 'append':
                        if(!isset($variables[$var])) $variables[$var] = '';
                        $variables[$var] .= $value;
                        break;
                }
                $tagdata = str_replace($match, '', $tagdata);
            }
        }
        $this->EE->TMPL->log_item('Portal: Match count = '.$count);
        $this->EE->TMPL->log_item('Portal: Variables = '.print_r($variables, TRUE));

        $tagdata = $this->EE->functions->prep_conditionals($tagdata, $variables);
        
        foreach($variables as $var => $value) {
            $tagdata = $this->EE->TMPL->parse_variables($tagdata, array($variables));
        }

        $this->return_data = $tagdata;
    }
}
 
