<?php 
/**
 * Developed by Biber Ltd. (http://www.biberltd.com)
 * 
 * version:         1.0.0
 * last update:     21 October 2010
 * author:          Can Berkol
 * copyright:       Biber Ltd. (http://biberltd.com)
 * license:         GPL v3.0
 * 
 * description:
 * Creates a field with a rop down of available languages as set in Biber Ltd. Multi Language Support
 * Extension.
 * 
 */ 

if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Bbr_languagelist_ft extends EE_Fieldtype {
	/**
	 * Fieldtype Information
	 */
	public $info = array(
		'name'     => 'Language List',
		'version'  => '1.0.0'
	);
    public $has_array_data = FALSE;
    private $prfx;
    private $addon_folder = 'bbr_languagelist';
    private $key;
	/**
	 * Constructor for PHP < 5.0
	 */
	function Bbr_languagelist_ft()
	{
		$this->__construct();
	}
    /**
     * Constructor
     * 
     * @since       1.0.0
     * @date        21.10.2010
     * @author      Can Berkol
     * 
     * PHP 5.0 & above
     */ 
    public function __construct(){
        $this->EE =& get_instance();
        $this->prfx = $this->EE->db->dbprefix;
        parent::__construct();
    }
    /**
     * Destructor
     * 
     * @since       1.0.0
     * @date        21.10.2010
     * @author      Can Berkol
     * 
     * PHP 5.0 & above
     */ 
    public function __destructor(){
        foreach($this as $property => $value){
            $this->$property = null;
        }
    }
    /**
     * install()
     * 
     * @since       1.0.0
     * @date        21.10.2010
     * @author      Can Berkol
     * 
     * Installs the field type only if Biber Ltd. Multi Language Extension is already installed.
     */ 
    public function install(){
        $sql = 'SELECT version FROM '.$this->prfx.'extensions WHERE class = "'
                .'Bbr_multilanguagesupport_ext" LIMIT 1';
        $result = $this->EE->db->query($sql);
        
        /**
         * Check if a compatible Biber Ltd. Multi Language Extension is installed.
         */ 
        $ext_version = $result->row('version');
        $ext_min = 110; /** (v 1.1.0) */
        $ext_version = (int) str_replace('.', '', $ext_version);
        if($ext_version < $ext_min){
            $this->uninstall();
        }
    }
    /**
     * display_field
     * 
     * @since       1.0.0
     * @date        21.10.2010
     * @author      Can Berkol
     * 
     * Displays the field in publish screen.
     */ 	
    public function display_field($data){
        $content = '';
        /**
         * Get all languages as defined in extension.
         */ 
        $sql = 'SELECT settings FROM '.$this->prfx.'extensions WHERE class = "'
                .'Bbr_multilanguagesupport_ext" LIMIT 1';
        $result = $this->EE->db->query($sql);
        $settings = unserialize($result->row('settings'));
        /**
         * Create options for selectbox
         */ 
        $options = array();
        $count = 0;
        foreach($settings['available_lang'] as $language){
            $options[$settings['available_lang_code'][$count]] = $language;
            $count++;
        }
        if(empty($data) || !isset($data)){
            $data = 'en';
        }
        $content = form_dropdown($this->settings['field_name'], $options, $data);
        return $content;
	}
    public function display_cell($data){
        $content = '';
        /**
         * Get all languages as defined in extension.
         */ 
        $sql = 'SELECT settings FROM '.$this->prfx.'extensions WHERE class = "'
                .'Bbr_multilanguagesupport_ext" LIMIT 1';
        $result = $this->EE->db->query($sql);
        $settings = unserialize($result->row('settings'));
        /**
         * Create options for selectbox
         */ 
        $options = array();
        $count = 0;
        foreach($settings['available_lang'] as $language){
            $options[$settings['available_lang_code'][$count]] = $language;
            $count++;
        }
        if(empty($data) || !isset($data)){
            $data = 'en';
        }
        $content = form_dropdown($this->cell_name, $options, $data);
        return $content;
    }
    public function save_cell($data){
        return $data;
    }

}
/**
 * Change Log:
 * 
 * * v 1.0.0
 * 
 * - Main release
 */
 
// END bbr_languagelist class

/* End of file ft.bbr_languagelist.php */
/* Location: ./expressionengine/third_party/bbr_languagelist/ft.bbr_languagelist.php */