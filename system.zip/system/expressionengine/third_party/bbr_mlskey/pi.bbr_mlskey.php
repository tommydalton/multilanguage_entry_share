<?php
/**
 * Developed by Biber Ltd. (http://www.biberltd.com)
 *
 * version:         1.0.0
 * last update:     16 September 2012
 * author:          Can Berkol
 * copyright:       Biber Ltd. (http://biberltd.com)
 *
 * description:
 * This plugin is used to list MLS translations.
 *
 * license:
 *  -   You can copy and re-distribute this source code without removing any credits to original
 *      programmer: Biber Ltd.
 *  -   You may not sell or re-sell this source code as is within a package or individually.
 *  -   You can enhance and modify this source code without removing the original credits.
 *
 */
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$plugin_info = array(
  'pi_name'     => 'Biber Ltd. MLS Keys (for Multi Language Support)',
  'pi_version'  => '1.0.0',
  'pi_author'   => 'Biber Ltd',
  'pi_author_url'=>'http://www.biberltd.com/wiki/English:bbr_mlskeys/',
  'pi_description'=>'Returns the list of MLS keys and corresponding translations.',
  'pi_usage' => Bbr_mlskey::usage()
);

class Bbr_mlskey {
    public $return_data = '';
    public $show_keys = '';               /** yes or no */
    public $show_translation = 'turkish'; /** none, all, or one of the defined languages' name */
    public $show_as = 'table';            /** table or list */
    public $class = '';
    private $extension_settings = '';

    /**
     * Constructor
     *
     * @since       1.0.0
     * @date        16.07.2010
     * @author      Can Berkol
     *
     * PHP 5.0 & above
     */
    public function __construct(){
        $this->EE =& get_instance();
        $this->prfx = $this->EE->db->dbprefix;
        $this->get_settings();
        if($this->EE->TMPL->fetch_param('show_keys')){
            $this->show_keys = $this->EE->TMPL->fetch_param('show_keys');
        }
        if($this->EE->TMPL->fetch_param('show_as')){
            $this->show_as = $this->EE->TMPL->fetch_param('show_as');
        }
        if($this->EE->TMPL->fetch_param('show_translation')){
            $this->show_translation = $this->EE->TMPL->fetch_param('show_translation');
        }
        if($this->EE->TMPL->fetch_param('class')){
            $this->class = $this->EE->TMPL->fetch_param('class');
        }
        $this->return_data = $this->output();
    }
    function Bbr_mlskey(){
        $this->__construct();
    }
    /**
     * Destructor
     *
     * @since       1.0.0
     * @date        16.07.2010
     * @author      Can Berkol
     *
     * PHP 5.0 & above
     */
    public function __destructor(){
        foreach($this as $property => $value){
            $this->$property = null;
        }
    }
    /**
     * output()
     *
     * @since       1.0.0
     * @date        16.09.2012
     * @author      Can Berkol
     *
     * @return      string
     */
    public function output(){
        // $languages = $this->list_languages();
        $translations = $this->list_translations();
        $parameters['class'] = $this->class;

        $html = '';
        if($this->show_as == 'table'){
           $html = $this->create_table($translations, $parameters);
        }
        else{
           $html = $this->create_list($translations, $parameters);
        }
        return $html;
    }
    /**
     * create_table()
     *
     * @since       1.0.0
     * @date        16.09.2012
     * @author      Can Berkol
     *
     * @return      string
     */
    public function create_table($translations, $parameters = array()){
        $table_open = '<table';
        foreach($parameters as $key => $value){
            $table_open .= ' '.$key.'="'.$value.'"';
        }
        $table_open .= '>';
        $table_close = '</table>';
        $table_body_open = '<tbody>';
        $table_body_close = '</tbody>';
        $table_head_open = '<thead>';
        $table_head_close = '</thead>';
        $column_open = '<td>';
        $column_close = '</td>';
        $row_open = '<tr>';
        $row_close = '</tr>';
        $rows = '';
        foreach($translations as $translation){
            $row = $row_open;
            $columns = '';
            foreach($translation as $key => $value){
                $column = $column_open;
                $column .= $value;
                $column .= $column_close;

                $columns .= $column;
            }
            $row .= $columns;
            $row .= $row_close;
            $rows .= $row;
        }
        $table = $table_open
                    .$table_head_open
                    .$table_head_close
                    .$table_body_open
                        .$rows
                    .$table_body_close
                .$table_close;
        return $table;
    }
    /**
     * create_list()
     *
     * @since       1.0.0
     * @date        16.09.2012
     * @author      Can Berkol
     *
     * @return      string
     */
    public function create_list($translations, $parameters = array()){
        $list_open = '<ul';
        foreach($parameters as $key => $value){
            $list_open .= ' '.$key.'="'.$value.'"';
        }
        $list_open .= '>';
        $list_close = '</ul>';
        $list_item_open = '<ul>';
        $list_item_close = '</ul>';
        $row_open = '<li>';
        $row_close = '</li>';
        $list = '';
        foreach($translations as $translation){
            $rows = '';
            $count = 0;
            $end = count($translation) - 1;
            if($this->show_keys == 'yes'){
                $rows .= $row_open.$translation->key;
                $rows .= $list_item_open;
            }
            $count = 0;
            foreach($translation as $key => $value){
                if($this->show_keys == 'yes' && $count == 0){
                    $count++;
                    continue;
                }
                $row = '';

                $row .= $row_open;
                $row .= $value;
                $row .= $row_close;

                $rows .= $row;

                $count++;
            }
            if($this->show_keys == 'yes'){
                $rows .= $list_item_close.$row_close;
            }
            $list .= $rows;
        }
        $list = $list_open
                    .$list
                .$list_close;
        return $list;
    }
    /**
     * list_languages()
     *
     * @since       1.0.0
     * @date        16.09.2012
     * @author      Can Berkol
     *
     * @return      string
     */
    protected function list_languages(){
        $names = $this->extension_settings['available_lang'];
        $aliases = $this->extension_settings['available_lang_alias'];
        $codes = $this->extension_settings['available_lang_code'];
        $count = 0;
        $languages = array();
        foreach($codes as $code){
            $language = new stdClass();
            $language->code = $code;
            $language->alias = $aliases[$count];
            $language->name = $names[$count];
            $count++;
            $languages[] = $language;
        }
        return $languages;
    }
    /**
     * list_translations()
     *
     * @since       1.0.0
     * @date        16.09.2012
     * @author      Can Berkol
     *
     * @return      string
     */
    protected function list_translations(){
        $names = $this->extension_settings['available_lang'];
        $texts = $this->extension_settings['texts'];
        $codes = $this->extension_settings['available_lang_code'];
        $translations = array();
        foreach($texts as $text){
            $translation = new stdClass();
            if($this->show_keys != 'no'){
                $translation->key = $text['key'];
            }
            if($this->show_translation != 'none'){
                foreach($names as $name){
                    $name = strtolower($name);
                    if($this->show_translation != 'all'){
                        if($this->show_translation == $name){
                            $translation->$name = $text[$name];
                        }
                    }
                    else{
                        $translation->$name = $text[$name];
                    }
                }
            }
            $translations[] = $translation;
        }
        return $translations;
    }
    /**
     * get_settings()
     *
     * @since       1.0.0
     * @date        16.09.2012
     * @author      Can Berkol
     *
     * @return      string
     */
    private function get_settings(){
        $query = 'SELECT settings FROM '
                    .$this->prfx.'extensions WHERE class = "Bbr_multilanguagesupport_ext" LIMIT 1';
        $result = $this->EE->db->query($query);
        $extension_settings = unserialize($result->row('settings'));
        $extension_settings['texts'] = unserialize(base64_decode($extension_settings['texts']));
        $this->extension_settings = $extension_settings;
    }
    /**
     * usage
     *
     * @since       1.0.0
     * @date        16.07.2010
     * @author      Can Berkol
     *
     * Shows usage information in plugin control panel.
     */
    public static function usage(){
      ob_start();
    ?>
    This plugin enables you to output all available MLS extension translations in your templates.

    The plugin accepts four parameters:

    - show_keys        yes, no.
                       If set to yes, it shows keys besides translations.


    - show_translation   none, all or one of the defined languages' name in lowercase.
                       If set to none it doesn't show any translation value, if set to all all
                       language translations will be listed, if set to a language name then only
                       translations of that language is shown.


    - show_as          table, list.

                       list values as table or list


    - class             any string
                        defines a class name for the main list container.

    EXAMPLES:


    List all translation keys as unordered list


    {exp:bbr_mlskey show_keys="yes" show_translation="none" show_as="list"}


    List all translation keys as table

    {exp:bbr_mlskey show_keys="yes" show_translation="none" show_as="table"}

    Show all translations with keys as table:

    {exp:bbr_mlskey show_keys="yes" show_translation="all" show_as="table"}

    Show all translations in Turkish without keys as table:

    {exp:bbr_mlskey show_keys="no" show_translation="turkish" show_as="table"}

      <?php

      $buffer = ob_get_contents();


      ob_end_clean();


      return $buffer;

      }

      // END

}


/* End of file pi.bbr_gettext.php */

/* Location: ./system/expressionengine/third_party/bbr_multilanguagesupport/pi.bbr_gettext.php */

?>
