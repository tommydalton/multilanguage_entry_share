<?php

$lang = array(

//----------------------------------------
// Required for MODULES page
//----------------------------------------

'stats_module_name' =>
'Statistics',

'stats_module_description' =>
'Statistics display module',

//----------------------------------------






''=>''
);

/* End of file stats_lang.php */
/* Location: ./system/expressionengine/language/english/stats_lang.php */