<?php
$lang = array(


'your_name' => 
'Tu Nombre',

'your_email' => 
'Tu Correo',

'recipient' => 
'Recipiente',

'cc' => 
'CC',

'bcc' => 
'BCC',

'recipient_group' => 
'Enviar a Grupos de Miembro',

'manual_recipients_ignored' => 
'El campo de recibo anterior sera ignorado',

'send_to_mailinglist' => 
'Enviar a Listas de Correo',

'honor_email_pref' => 
'Enviar solo a miembros que han escodigo aceptar email',

'separate_emails_with_comma' => 
'Separa multiples direcciones de correo con un coma',

'no_email_matching_criteria' => 
'No hay direcciones de correo que concuerdan con tu criterio seleccionado',

'not_allowed_to_email_members' => 
'No tienes permitido enviar correo a miembros',

'not_allowed_to_email_member_groups' => 
'No tienes permitido enviar correos a Grupos de Miembro',

'not_allowed_to_email_mailinglist' => 
'No tienes permitido enviar correo a la lista de correo',

'subject' => 
'Tema',

'message' => 
'Mensaje',

'plaintext_alt' => 
'Alternativa de Texto Simple (opcional, correos de solo HTML, sin formato de texto aplicado)',

'send_an_email' => 
'Enviar un Email',

'sending_email' => 
'Enviando Email',

'batchmode_ready_to_begin' => 
'La rutina de envio de correo empezara en cinco segundos',

'batchmode_warning' => 
'No toques tu explorador hasta que el proceso termine por completo!',

'problem_with_id' => 
'En problema fue encontrado con el ID necesario para enviar correos',

'cache_data_missing' => 
'Los datos de cache de email no fueron encontrados.',

'currently_sending_batch' => 
'Ahora enviando correos %x hasta %y',

'emails_remaining' => 
'Correos Restantes:',

'email_error' => 
'Error de Email',

'send_it' => 
'Enviarlo',

'total_emails_sent' => 
'Cantidad total de emails enviados:',

'plain_text' => 
'Texto Simple',

'html' => 
'HTML',

'mail_format' => 
'Formato de Email',

'text_formatting' => 
'Formato de Texto',

'none' => 
'Ninguno',

'auto_br' => 
'&lt;br /&gt; auto',

'xhtml' => 
'XHTML',

'wordwrap' => 
'Envoltura Word',

'priority' => 
'Prioridad',

'attachment' => 
'Adjunto',

'attachment_problem' => 
'Hubo un problema adjuntando tu archivo.',

'attachment_unavailable' => 
'Para que se envien adjuntos, una ubicacion de carga debe ser definida.',

'attachment_warning' => 
'Adjuntos no son guardados por ExpressionEngine, y deben ser guardados localmente.',

'chars' => 
'caracteres',

'highest' => 
'Mas Alto',

'high' => 
'Alto',

'normal' => 
'Normal',

'low' => 
'Bajo',

'lowest' => 
'Mas Bajo',

'empty_form_fields' => 
'Dejastes algunos campos sin llenar.',

'email_sent_message' => 
'To correo ha sido enviado',

'all_email_sent_message' => 
'Todos los correos han sido enviados',

'email_success' => 
'Correo Enviado',

'view_email_cache' => 
'Ver Correos Enviados Previamente',

'previous_email' => 
'Correo Enviado Previamente',

'email_title' => 
'Titulo de Correo',

'email_date' => 
'Fecha Enviado',

'total_recipients' => 
'Total de Recipientes',

'resend' => 
'Re-enviar',

'view' => 
'Ver',

'no_cached_email' => 
'No hay correos en cache',

'delete_emails' => 
'Borrar Correo',

'delete_confirm' => 
'Borrar Configuracion de Correo',

'delete_question' => 
'Estas seguro que quieres borrar los correos especificados?',

'bad_cache_ids' => 
'No hay correos que concuerdan con los criterios seleccionados',

'email_deleted' => 
'Correo ha sido borrado',

'mailinglist_unsubscribe' => 
'Para remover tu correo de la lista de correo, haz click aqui:',

'mailinglist_unsubscribe_all' => 
'Para remover tu correo de todas las listas de correo, haz click aqui:',

'complete' => 
'Completo',

'incomplete' => 
'Incompleto',

'on' => 
'Encendido',

'off' => 
'Apagado',

'translate' => 
'Update',

''=>''
);

// End of File