<?php
$lang = array(


"stats_module_name" =>
"Estadísticas",

"stats_module_description" =>
"Módulo de presentación de estadísticas",

"translate" =>
"Update",

''=>''
);
?>