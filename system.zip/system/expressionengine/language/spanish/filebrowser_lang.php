<?php
$lang = array(


'file_browser' => 
'Explorador de Archivos',

'view' => 
'Ver',

'path_does_not_exist' => 
'La ruta especificada no existe',

'file_viewing_error' => 
'Un error de tipo desconocido fue encontrado.',

'fp_no_files' => 
'No hay archivos disponibles en el directorio.',

'fb_view_images' => 
'Ver Imagenes',

'fb_view_image' => 
'Ver Imagen',

'fb_insert_file' => 
'Insertar Archivo',

'fb_insert_files' => 
'Insertar Archivos',

'fb_select_field' => 
'Seleccionar Campo',

'fb_select_files' => 
'Seleccionar Archivos',

'fb_non_images' => 
'* Indica no imagenes. Solo imagenes pueden ser vistas.',

'fb_insert_link' => 
'Insertar Enlace',

'fb_insert_links' => 
'Insertar Enlaces',

'fb_insert_url' => 
'Insertar URL',

'fb_insert_urls' => 
'Insertar URLs',

'translate' => 
'Update',

''=>''
);

// End of File