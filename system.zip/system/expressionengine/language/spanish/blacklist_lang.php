<?php
$lang = array(


"blacklist_module_name" =>
"Lista Negra/Lista Blanca",

"blacklist_module_description" =>
"Modulo de lista negra y lista blanca",

"htaccess_written_successfully" =>
"El archivo .htaccess fue escrito con exito",

"invalid_htaccess_path" =>
"Ruta o Permisos Invalidos para archivo .htaccess",

"htaccess_server_path" =>
"Ruta de Servidor para archivo .htaccess",

"write_htaccess_file" =>
"Escribir lista negra a archivo .htaccess?",

"whitelist" =>
"Lista Blanca",

"pmachine_whitelist" =>
"Descargar Lista Blanca de ExpressionEngine.com",

"whitelist_updated" =>
"Lista Blanca actualizada exitosamente",

"ref_whitelist_irretrievable" =>
"Error: lista blanca nueva fue iremediable.",

"ref_view_whitelist" =>
"Ver Lista Blanca",

"ref_no_whitelist" =>
"Actualmente no hay nada en la lista blanca",

"ref_whitelisted" =>
"Agregado a Lista Blanca",

"ref_no_whitelist_table" =>
"No existe la tabla de lista blanca en base de datos",

"ref_type" =>
"Tipo de Articulo",

"blacklist" =>
"Lista Negra",

"pmachine_blacklist" =>
"Descargar Lista Negra de ExpressionEngine.com",

"requires_license_number" =>
"Requiere Numero de Licencia en Configuracion General",

"blacklist_updated" =>
"Lista Negra actualizada exitosamente",

"ref_no_license" =>
"Error: sin numero de licencia.",

"ref_blacklist_irretrievable" =>
"Error: la lista negra fue iremediable.",

"ref_view_blacklist" =>
"Ver Lista Negra",

"ref_no_blacklist" =>
"Actualmente no hay nada en la lista negra",

"ref_ip" =>
"Direcciones IP",

"ref_user_agent" =>
"Agente de Usuario",

"ref_url" =>
"URL",

"ref_blacklisted" =>
"Agregado a lista negra",

"ref_no_blacklist_table" =>
"Table de lista negra no existe en la base de datos",

"translate" =>
"Update",

''=>''
);
?>