<?php
$lang = array(


'email_module_name' => 
'Correo Electronico',

'email_module_description' => 
'Modulo de Usuario de Correo Electronico',

'message_required' => 
'Mensjae de Correo es Requerido',

'em_banned_from_email' => 
'La direccion de correo del remitente ha sido blockeada.',

'em_banned_recipient' => 
'Una o mas direcciones de correos de tus recipientes han sido blockeadas.',

'em_invalid_recipient' => 
'Una o mas direcciones de correo de tus recipientes son invalidas.',

'em_no_valid_recipients' => 
'Tu correo no tiene recipientes validos.',

'em_sender_required' => 
'Un remitente valido de correo es requerido',

'em_unauthorized_request' => 
'No tienes autorizacion para llevar a cabo esta accion',

'em_limit_exceeded' => 
'Has excedido el numero de envio de correos permitodos por dia.',

'em_interval_warning' => 
'Solo tiene permitido enviar correos cada %s segundos',

'em_email_sent' => 
'Tu mensaje de correo ha sido enviado.',

'translate' => 
'Update',

''=>''
);

// End of File