<?php
$lang = array(


"spell_check" =>
"Correción de Ortografía",

"check_spelling" =>
"Corregir Ortografía",

"save_spellcheck" =>
"Guardar Cambios",

"revert_spellcheck" =>
"Revertir a Original",

"spell_save_edit" =>
"Guardar Edición",

"spell_edit_word" =>
"Editar Palabra",

"unsupported_browser" =>
"Navegador Sin Soporte",

"no_spelling_errors" =>
"No Se Encontraron Errores",

"spellcheck_in_progress" =>
"Corrección en Progreso...",

"translate" =>
"Update",

''=>''
);
?>