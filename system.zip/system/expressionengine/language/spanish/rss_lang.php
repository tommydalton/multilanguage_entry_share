<?php
$lang = array(


"rss_module_name" =>
"RSS",

"rss_module_description" =>
"Módulo de generación de página RSS",

"rss_invalid_channel" =>
"El canal especificado en tu feed RSS no existe.",

"translate" =>
"Update",

''=>''
);
?>