<?php
$lang = array(


'addons' => 
'Add-ons',

'accessories' => 
'Accesorios',

'modules' => 
'Modulos',

'extensions' => 
'Extensiones',

'plugins' => 
'Plugins',

'accessory' => 
'Accesorio',

'module' => 
'Modulo',

'extension' => 
'Extension',

'addons_accessories' => 
'Accesorios',

'addons_modules' => 
'Modulos',

'addons_plugins' => 
'Plugins',

'addons_extensions' => 
'Extensiones',

'addons_fieldtypes' => 
'Typos de Campo',

'accessory_name' => 
'Nombre de Accesorio',

'fieldtype_name' => 
'Nombre de Tipo de Campo',

'install' => 
'Instalar',

'uninstall' => 
'Desinstalar',

'installed' => 
'Instalado',

'not_installed' => 
'No Instalado',

'uninstalled' => 
'Desinstalado',

'remove' => 
'Remover',

'preferences_updated' => 
'Preferencias Actualizadas',

'extension_enabled' => 
'Extension Habiltada',

'extension_disabled' => 
'Extension Deshabilitada',

'extensions_enabled' => 
'Extensiones Habilitadas',

'extensions_disabled' => 
'Extensiones Deshabilitadas',

'delete_fieldtype_confirm' => 
'Estas seguro que deseas remover este tipo de campo?',

'delete_fieldtype' => 
'Remover Tipo de Campo',

'data_will_be_lost' => 
'Todos los datos relacionados con este tipo de campo, incluyendo datos de canal asociados, seran borrados permanentemente!',

'global_settings_saved' => 
'Configuracion Guardada',

'package_settings' => 
'Configuracion de Paquete',

'component' => 
'Componente',

'current_status' => 
'Estatus Actual',

'available_to_member_groups' => 
'Disponible a Grupos de Miembro',

'specific_page' => 
'Pagina Espcifica?',

'description' => 
'Descripcion',

'version' => 
'Version',

'status' => 
'Estatus',

'edit_accessory_preferences' => 
'Editar Preferencias de Accesorio',

'member_group_assignment' => 
'Grupos de Miembro Asignados',

'page_assignment' => 
'Paginas Asignadas',

'none' => 
'Ninguno',

'and_more' => 
'y %x mas...',

'translate' => 
'Update',

''=>''
);

// End of File