<?php
$lang = array(


"remember_me" =>
"Acceder automaticamente en futuras visitas?",

"no_username" =>
"El campo de nombre de usuario es requerido.",

"no_password" =>
"El campo de contraseña es requerido.",

"no_email" =>
"Debes enviar tu dirección de correo electrónico.",

"credential_missmatch" =>
"Usuario o contraseña invalida.",

"multi_login_warning" =>
"Alguien ya ha accedido con esta cuenta.",

"return_to_login" =>
"Retornar a formulario de entrada",

"password_lockout_in_effect" =>
"Solo tiene permitodos cuatro intentos para acceder cada %x minuto(s)",

"unauthorized_request" =>
"No estás autorizado para llevar a cabo esta acción",

"translate" =>
"Update",

''=>''
);
?>